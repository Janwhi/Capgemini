import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-insurance',
  templateUrl: './purchase-insurance.component.html',
  styleUrls: ['./purchase-insurance.component.css']
})
export class PurchaseInsuranceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  Insurance_name: string;
  Insurance_Type: number;
  Insurance_Status: number;
  Insurance_Period_in_year: number;
}
