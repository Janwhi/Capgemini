package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsuranceController
 */
@WebServlet("/InsuranceController")
public class InsuranceController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public InsuranceController() {
		super();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		long Minimum_Entry_Age = Long.parseLong(request.getParameter("Minimum_Entry_Age"));
		String Maximum_Entry_Age = request.getParameter("Maximum_Entry_Age");
		
		if(String.valueOf(Minimum_Entry_Age).length()==90) {
			RequestDispatcher rd = request.getRequestDispatcher("InsurancePurchased.jsp");
			rd.forward(request, response);
	}
	}

}
