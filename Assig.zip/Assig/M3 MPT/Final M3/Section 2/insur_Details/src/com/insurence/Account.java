package com.insurence;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Account {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int insured_Id;
	private String insurer_aame;
	private String insurer_address;
	private String insurer_type;

	public Account(String insurer_aame, String insurer_address, String insurer_type) {
		super();
		this.insurer_aame = insurer_aame;
		this.insurer_address = insurer_address;
		this.insurer_type = insurer_type;
	}

	public Account() {
	}

	public int getInsured_Id() {
		return insured_Id;
	}

	public void setInsured_Id(int insured_Id) {
		this.insured_Id = insured_Id;
	}

	public String getInsurer_aame() {
		return insurer_aame;
	}

	public void setInsurer_aame(String insurer_aame) {
		this.insurer_aame = insurer_aame;
	}

	public String getInsurer_address() {
		return insurer_address;
	}

	public void setInsurer_address(String insurer_address) {
		this.insurer_address = insurer_address;
	}

	public String getInsurer_type() {
		return insurer_type;
	}

	public void setInsurer_type(String insurer_type) {
		this.insurer_type = insurer_type;
	}

}
