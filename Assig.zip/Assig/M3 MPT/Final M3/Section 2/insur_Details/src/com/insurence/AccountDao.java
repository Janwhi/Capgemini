package com.insurence;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.insurence.Account;

public class AccountDao {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();

		Scanner sc = new Scanner(System.in);
		AccountDao ac = new AccountDao();
		Account in = null;

		System.out.println("Enter insurer Name: ");
		String name = sc.next();

		System.out.println("Enter insurer Address: ");
		String address = sc.next();

		System.out.println("Enter insurer Type: ");
		String type = sc.next();

		if (type == null && type.length() == 0) {
			System.out.println("Insurer Type must not be Empty");
		} else {
			in = new Account(name, address, type);
		}
		em.persist(in);
		em.getTransaction().commit();
	}
}
