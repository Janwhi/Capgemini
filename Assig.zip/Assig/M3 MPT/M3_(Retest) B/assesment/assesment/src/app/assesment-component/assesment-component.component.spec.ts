import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssesmentComponentComponent } from './assesment-component.component';

describe('AssesmentComponentComponent', () => {
  let component: AssesmentComponentComponent;
  let fixture: ComponentFixture<AssesmentComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssesmentComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssesmentComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
