package module;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Assessment{
	@Id
		private int Emp_id;
		private String Module1;
		private String Module2;
		private String Module3;
		private String PLP;
		public Assessment(int emp_id, String module1, String module2, String module3, String pLP) {
			super();
			Emp_id = emp_id;
			Module1 = module1;
			Module2 = module2;
			Module3 = module3;
			PLP = pLP;
		}
		public Assessment(String module1, String module2, String module3, String pLP) {
			super();
			Module1 = module1;
			Module2 = module2;
			Module3 = module3;
			PLP = pLP;
		}
		public Assessment() {
			super();
			// TODO Auto-generated constructor stub
		}
		public int getEmp_id() {
			return Emp_id;
		}
		public void setEmp_id(int emp_id) {
			Emp_id = emp_id;
		}
		public String getModule1() {
			return Module1;
		}
		public void setModule1(String module1) {
			Module1 = module1;
		}
		public String getModule2() {
			return Module2;
		}
		public void setModule2(String module2) {
			Module2 = module2;
		}
		public String getModule3() {
			return Module3;
		}
		public void setModule3(String module3) {
			Module3 = module3;
		}
		public String getPLP() {
			return PLP;
		}
		public void setPLP(String pLP) {
			PLP = pLP;
		}
		@Override
		public String toString() {
			return "Assessment [Emp_id=" + Emp_id + ", Module1=" + Module1 + ", Module2=" + Module2 + ", Module3="
					+ Module3 + ", PLP=" + PLP + "]";
		}
		
		
}

   
