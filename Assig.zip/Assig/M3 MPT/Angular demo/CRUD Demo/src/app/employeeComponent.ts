import { Component } from '@angular/core';
import { Employee } from './employee';

@Component
({
	selector : 'emp-app' ,
	templateUrl : './employeeView.html'
})

export class EmployeeComponent
{
	empId : number;
	empName : string;
	empSalary : number;
	empDept : string;
	message :string;
	storeData : any={};


	empIdU : number;
	empNameU : string;
	empSalaryU : number;
	empDeptU : string;
	messageU : string;
	empIdUpdated : number;



	empArray: Employee[]=[
	{empId:1,empName:"Mohammed",empSalary:20000,empDept:"LnD-Java"},
	{empId:2,empName:"Ishaque",empSalary:25000,empDept:"LnD-Angular"},
	{empId:3,empName:"Basha",empSalary:40000,empDept:"LnD-Cloud"}
	];

	
	addEmp()
	{
	if(this.empId!=null || this.empName!="" || this.empSalary!=null || this.empDept!="")
		{
		this.storeData={empId: this.empId, empName: this.empName, empSalary: this.empSalary, empDept: this.empDept};

		this.empArray.push(this.storeData);
		this.message="Data Inserted";
		this.empId=null;
		this.empName="";
		this.empSalary=null;
		this.empDept="";
		}
		else
		{
			alert("Data you entered is Invalid");
		}		
	}


	deleteEmp(empId)
	{
		if(empId!=undefined)
		{
		let count=0;
			for(let i in this.empArray)
			{
			      if(this.empArray[i].empId==empId)
			      {
				this.empArray.splice(count,1);
			      }
			      count++;
			}
		}
	}

	updDetails(data)
	{
	this.empIdU = data.empId;
	this.empNameU = data.empName;
	this.empSalaryU = data.empSalary;
	this.empDeptU = data.empDept;
	this.empIdUpdated = data.empId;
	}

	updateEmp()
	{
	let updateVar="";
		if(this.empIdU!=undefined)
		{
		     for(let i in this.empArray)
		     {
		       if(this.empArray[i].empId==this.empIdUpdated)
			updateVar=i;
		     }
		     if(updateVar!="")
		     {
		          this.empArray[updateVar]={ empId: this.empIdU, empName: this.empNameU, empSalary: this.empSalaryU, empDept: this.empDeptU
					       };
			this.empIdU=null;
			this.empNameU="";
			this.empSalaryU=null;
			this.empDeptU="";  	
		     }
		}
	}

}