"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var EmployeeComponent = /** @class */ (function () {
    function EmployeeComponent() {
        this.storeData = {};
        this.empArray = [
            { empId: 1, empName: "Mohammed", empSalary: 20000, empDept: "LnD-Java" },
            { empId: 2, empName: "Ishaque", empSalary: 25000, empDept: "LnD-Angular" },
            { empId: 3, empName: "Basha", empSalary: 40000, empDept: "LnD-Cloud" }
        ];
    }
    EmployeeComponent.prototype.addEmp = function () {
        if (this.empId != null || this.empName != "" || this.empSalary != null || this.empDept != "") {
            this.storeData = { empId: this.empId, empName: this.empName, empSalary: this.empSalary, empDept: this.empDept };
            this.empArray.push(this.storeData);
            this.message = "Data Inserted";
            this.empId = null;
            this.empName = "";
            this.empSalary = null;
            this.empDept = "";
        }
        else {
            alert("Data you entered is Invalid");
        }
    };
    EmployeeComponent.prototype.deleteEmp = function (empId) {
        if (empId != undefined) {
            var count = 0;
            for (var i in this.empArray) {
                if (this.empArray[i].empId == empId) {
                    this.empArray.splice(count, 1);
                }
                count++;
            }
        }
    };
    EmployeeComponent.prototype.updDetails = function (data) {
        this.empIdU = data.empId;
        this.empNameU = data.empName;
        this.empSalaryU = data.empSalary;
        this.empDeptU = data.empDept;
        this.empIdUpdated = data.empId;
    };
    EmployeeComponent.prototype.updateEmp = function () {
        var updateVar = "";
        if (this.empIdU != undefined) {
            for (var i in this.empArray) {
                if (this.empArray[i].empId == this.empIdUpdated)
                    updateVar = i;
            }
            if (updateVar != "") {
                this.empArray[updateVar] = { empId: this.empIdU, empName: this.empNameU, empSalary: this.empSalaryU, empDept: this.empDeptU
                };
                this.empIdU = null;
                this.empNameU = "";
                this.empSalaryU = null;
                this.empDeptU = "";
            }
        }
    };
    EmployeeComponent = __decorate([
        core_1.Component({
            selector: 'emp-app',
            templateUrl: './employeeView.html'
        })
    ], EmployeeComponent);
    return EmployeeComponent;
}());
exports.EmployeeComponent = EmployeeComponent;
