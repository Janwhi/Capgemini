import { DemoProject1Page } from './app.po';

describe('demo-project1 App', function() {
  let page: DemoProject1Page;

  beforeEach(() => {
    page = new DemoProject1Page();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
