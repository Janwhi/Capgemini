import {Component} from '@angular/core';

@Component({

selector : '<my-component></my-component>' ,

templateUrl : './employee.html'
})

export class EmployeeComponent
{
empId : number =1001;
empName : string ="Ishaque";
empDept : string = "Java";
empSalary : number = 20000;

}
