interface Flight{
    flightId: number;
    flightName: string;
    flightNumber :number;
    flightCode: number;
    noOfSeats: number;
    flightType: number;

     display(flightId: number,flightName: string ,flightNumber :number,flightCode: number, noOfSeats: number,flightType: number);


    }