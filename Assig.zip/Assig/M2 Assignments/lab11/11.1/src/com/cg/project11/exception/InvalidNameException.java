package com.cg.project11.exception;

public class InvalidNameException extends Exception {

	public InvalidNameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
