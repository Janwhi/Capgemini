package com.cg.project11.view;

import java.util.Scanner;

import com.cg.project11.exception.InvalidMailException;
import com.cg.project11.exception.InvalidMobileIdException;
import com.cg.project11.exception.InvalidNameException;
import com.cg.project11.exception.InvalidPhoneNoException;
import com.cg.project11.validate.ValidatePurchaseDetails;

public class GetInputForPurchase {

	Scanner sc = new Scanner(System.in);
	ValidatePurchaseDetails vp = new ValidatePurchaseDetails();

	public String getCustName() {
		String temp1 = null;
		try {
			System.out.println("Enter name of person...");
			temp1 = sc.next();
			if (!vp.isCustName(temp1)) {
				throw new InvalidNameException();
			} else {

			}
		} catch (InvalidNameException e) {
			System.out.println(
					"Please make sure that name start with a capital letter and has maximum size of 20 characters.");
			getCustName();
		}
		return temp1;
	}

	public String getMailId() {
		String temp2 = null;
		try {
			System.out.println("Enter mail of person...");
			temp2 = sc.next();
			if (!vp.isMailId(temp2)) {
				throw new InvalidMailException();
			} else {

			}
		} catch (InvalidMailException e) {
			System.out.println("Entered E-Mail is invalid Please try again...");
			getMailId();
		}
		return temp2;
	}

	public String getPhoneNo() {
		String temp3 = null;
		try {
			System.out.println("Enter phone no of person...");
			temp3 = sc.next();
			if (!vp.isPhoneNo(temp3)) {

				throw new InvalidPhoneNoException();
			} else {

			}
		} catch (InvalidPhoneNoException e) {
			System.out.println("Enter 10 digit long Phone number....");
			getPhoneNo();
		}
		return temp3;
	}

	public String getMobId() {
		String temp4 = null;
		try {
			System.out.println("Enter mobile id...");
			temp4 = sc.next();
			if (!vp.isMobId(temp4)) {
				throw new InvalidMobileIdException();
			} else {

			}
		} catch (

		InvalidMobileIdException e) {
			System.out.println("Mobile Id should be 4 digit long .....  ");
			getMobId();
		}
		return temp4;
	}

}
