package com.cg.project11.exception;

public class ItemNotAvailableException extends Exception {

	public ItemNotAvailableException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ItemNotAvailableException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
