package com.cg.project11.testcase;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.cg.project11.doa.MobilePurchaseDOA;
import com.cg.project11.models.PurchaseDetails;

public class TestMobile {

	MobilePurchaseDOA doi = new MobilePurchaseDOA();
	PurchaseDetails pd = new PurchaseDetails("Bakayo Sako", "sako@hotmail.com", "9980465372", "1007");
	PurchaseDetails pd1 = new PurchaseDetails("iaiz", "faiz@gmail.com", "9807465372", "1007");
	PurchaseDetails pd2 = new PurchaseDetails("Faiz", "faizgmail.com", "907465372", "1007");
	PurchaseDetails pd3 = new PurchaseDetails("Faiz", "faiz@gmail.com", "07465372", "1007");
	PurchaseDetails pd4 = new PurchaseDetails("Faiz", "faiz@gmail.com", "9807465372", "100");
	
	@Test
	public void testSearch() {
		assertTrue(doi.searchOnPrice(10000,20000));
		assertFalse(doi.searchOnPrice(0, -19999));
		assertFalse(doi.searchOnPrice(-19000, 0));
		assertFalse(doi.searchOnPrice(20000, 10000));

	}
	
	@Test
	public void testInsert() {
		assertTrue(doi.addPerchaseRec(pd, 1));
		assertFalse(doi.addPerchaseRec(pd2, 1));
		assertFalse(doi.addPerchaseRec(pd3, 1));
		assertFalse(doi.addPerchaseRec(pd4, 1));
		assertFalse(doi.addPerchaseRec(pd1, 1));
		assertFalse(doi.addPerchaseRec(pd1, 0));

	}

}
