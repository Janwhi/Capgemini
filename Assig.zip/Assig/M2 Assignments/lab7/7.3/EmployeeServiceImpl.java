package com.cg.lab7_3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	//HashMap<String, Employee> list = new HashMap<String, Employee>();

	public void showEmployee(HashMap<String, Employee> list) {
		System.out.println(list.values());
	}

	@Override
	public void displayEmployeeBasedInsurence(String insurence, HashMap<String, Employee> list) {
		Iterator itr = list.entrySet().iterator();
		System.out.println("\t ID \t NAME \t SALARY \t DESIGNATION \t INSURENCE SCHEME");

		while (itr.hasNext()) {
			Map.Entry map1 = (Map.Entry) itr.next();
			Employee ins = (Employee) map1.getValue();
			if (ins.getInsuranceScheme().equals(insurence)) {
				System.out.println("\t"+ ins.getId()+" \t"+ ins.getName()+" \t" +ins.getSalary()+" \t"+ ins.getDesignation()+" \t"+ ins.getInsuranceScheme());
			}
		}

	}

	@Override
	public boolean deleteEmployee(int id, HashMap<String, Employee> list) {
		boolean fl = false;
		Iterator itr = list.entrySet().iterator();
		while (itr.hasNext()) {
			Map.Entry map1 = (Map.Entry) itr.next();
			Employee ins = (Employee) map1.getValue();
			if (ins.getId() == id) {
				itr.remove();
				fl = true;
			}
				
		}
		return fl;
	}

	@Override
	public void sortOnSalary(HashMap<String, Employee> list) {

		Set<Employee> list1 = new TreeSet<Employee>(new SortOnSal());
		Iterator itr = list.entrySet().iterator();
		while (itr.hasNext()) {
			Map.Entry map1 = (Map.Entry) itr.next();
			Employee ins = (Employee) map1.getValue();
			list1.add(ins);
		}
		System.out.println("\t ID \t NAME \t SALARY \t DESIGNATION \t INSURENCE SCHEME");
			for(Employee e: list1)
			{
				System.out.println("\t"+ e.getId()+" \t"+ e.getName()+" \t" +e.getSalary()+" \t"+ e.getDesignation()+" \t"+ e.getInsuranceScheme());
			}
	}
}
