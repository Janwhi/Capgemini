package com.cg.lab7_3;

public class EmployeeException extends Exception {

	public EmployeeException() {
		super();
	}

	public EmployeeException(String arg0) {
		super(arg0);
	}

}
