package com.cg.lab3;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
public class AssgSevenProg {

	public static int[] calculateAge(String dob)
	{
		DateTimeFormatter fr = null;
		fr = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate ld = LocalDate.parse(dob, fr);
		LocalDate ld1 = LocalDate.now();
		Period pe = ld.until(ld1);
		int a = Math.abs(pe.getYears());  
		int b = Math.abs(pe.getMonths());
		int c = Math.abs(pe.getDays());
		int[] out = {a,b,c};
		return out;
	}
	public static String getFullName(String firstname, String lastname)
	{
		String out = firstname + " "+ lastname;
		return out;
	}
	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter name of person:");
		String fname = sc.next();
		String lname = sc.next();
		String name = getFullName(fname,lname);
		System.out.println("Enter date of birth of "+ fname + ":");
		String dob = sc.next();
		int[] out = calculateAge(dob);
		System.out.println("Full Name is : "+ name);
		System.out.println("Age of "+name + " is -> "+ out[0]+" :Years , " + out[1] +" :Months , "+ out[2]+ " :Days.");
		sc.close();
	}

}
