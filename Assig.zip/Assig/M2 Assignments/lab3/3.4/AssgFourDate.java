package com.cg.lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class AssgFourDate {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter first date to get duration -> [dd-MM-yyyy]");
		String str = sc.next();
		System.out.println("Enter second date date to get duration -> [dd-MM-yyyy](must be later that first date)");
		String str1 = sc.next();
		DateTimeFormatter fr = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate dl = LocalDate.parse(str,fr);
		LocalDate dk = LocalDate.parse(str1,fr);
		Period period = dl.until(dk);

		System.out.println("Duration is -> ");
		System.out.println( period.getYears()+" Years , " + period.getMonths()+ " Months , "+ period.getDays()+ " days . ");
		sc.close();

	}

}
