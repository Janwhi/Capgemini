package com.cg.lab3;

import java.util.*;

public class StringOp1 {

	public String addString(String str) {
		String out = str + str;
		return out;
	}

	public char[] replaceOdd(String str) {
		int i = str.length();
		char a[] = (str.toCharArray());
		// System.out.println(a);
		for (int j = 0; j < i; j++) {
			if (j % 2 == 0) {
				a[j] = '#';
			}
		}
		return a;
	}

	public String removeDub(String str) {
		// int i = str.length();
		char a[] = str.toCharArray();
		Set<Character> newset = new LinkedHashSet<Character>();
		for (Character c : a) {
			newset.add(c);
		}
		String o = newset.toString();
		int k = o.length();
		char ou[] = o.toCharArray();
		String out = "";
		for (int j = 0; j < k; j++) {
			if (ou[j] != ',' && ou[j] != '[' && ou[j] != ']' && ou[j] != ' ') {
				out += ou[j];
			}
		}
		return out;
	}

	public String upperOdd(String str) {
		int i = str.length();
		char a[] = str.toCharArray();

		String s1 = "";
		char ch = 0;
		for (int j = 0; j < i; j++) {
			if (j % 2 == 0) {
				ch = a[j];
				s1 += Character.toUpperCase(ch);
			} else {
				s1 += a[j];
			}

		}
		return s1;
	}

	public static void main(String[] args) {
		StringOp1 ob1 = new StringOp1();

		Scanner sc = new Scanner(System.in);
		int abc = 0;
		while (true) {
			System.out.println("\nSelect One from below");
			System.out.println("1.Add String");
			System.out.println("2.Replace odd Character with #");
			System.out.println("3.Remove Duplicate Characters");
			System.out.println("4.Replace odd character with Upper Case");
			System.out.println("5.Exit");
			abc = sc.nextInt();
			switch (abc) {
			case 1:
				System.out.println("Enter a string:");
				String str = sc.next();
				String get = ob1.addString(str);
				System.out.println(get);
				break;

			case 2:
				System.out.println("Enter a string:");
				String str1 = sc.next();
				char get1[] = ob1.replaceOdd(str1);
				System.out.println(get1);
				break;

			case 3:
				System.out.println("Enter a string:");
				String str2 = sc.next();
				String get2 = ob1.removeDub(str2);
				System.out.println(get2);
				break;

			case 4:
				System.out.println("Enter a string:");
				String str3 = sc.next();
				String getOddString = ob1.upperOdd(str3);
				System.out.println(getOddString);
				break;

			case 5:
				return;
			default:
				System.out.println("Please Enter a valid Choice...");
				break;
			}

		}

	}
}
