package com.cg.lab8.p8_3;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import lab5.com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeService,Serializable{
	// HashMap<String, Employee> list = new HashMap<String, Employee>();

	public void showEmployee(HashMap<String, Employee> list) {
		System.out.println(list.values());
	}

	@Override
	public void displayEmployeeBasedInsurence(String insurence, HashMap<String, Employee> list) {
		Iterator itr = list.entrySet().iterator();
		System.out.println("\t ID \t NAME \t SALARY \t DESIGNATION \t INSURENCE SCHEME");

		while (itr.hasNext()) {
			Map.Entry map1 = (Map.Entry) itr.next();
			Employee ins = (Employee) map1.getValue();
			if (ins.getInsuranceScheme().equals(insurence)) {
				System.out.println("\t" + ins.getId() + " \t" + ins.getName() + " \t" + ins.getSalary() + " \t"
						+ ins.getDesignation() + " \t" + ins.getInsuranceScheme());
			}
		}

	}

	@Override
	public boolean deleteEmployee(int id, HashMap<String, Employee> list) {
		boolean fl = false;
		Iterator itr = list.entrySet().iterator();
		while (itr.hasNext()) {
			Map.Entry map1 = (Map.Entry) itr.next();
			Employee ins = (Employee) map1.getValue();
			if (ins.getId() == id) {
				itr.remove();
				fl = true;
			}

		}
		return fl;
	}

	@Override
	public void sortOnSalary(HashMap<String, Employee> list) {

		Set<Employee> list1 = new TreeSet<Employee>(new SortOnSal());
		Iterator itr = list.entrySet().iterator();
		while (itr.hasNext()) {
			Map.Entry map1 = (Map.Entry) itr.next();
			Employee ins = (Employee) map1.getValue();
			list1.add(ins);
		}
		System.out.println("\t ID \t NAME \t SALARY \t DESIGNATION \t INSURANCE SCHEME");
		for (Employee e : list1) {
			System.out.println("\t" + e.getId() + " \t" + e.getName() + " \t" + e.getSalary() + " \t"
					+ e.getDesignation() + " \t" + e.getInsuranceScheme());
		}
	}

	@Override
	public void printToFile(HashMap<String, Employee> list){
	/*	File dr = new File("mydir");
		File dat = new File("mydir", "EmployeeDetails.txt");*/
		boolean fl = false;
		/*if (!dr.exists()) {
			dr.mkdir();
		}
		try {
			if (!dat.exists()) {
				dat.createNewFile();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		
		try {
			FileOutputStream fout =
			         new FileOutputStream("EmployeeDetails.txt",false);
			ObjectOutputStream oos = new ObjectOutputStream(fout);
			FileWriter wri = new FileWriter("EmployeeDetails.txt");

		//	Map<Employee> list1 = new TreeMap<Employee>(new SortOnSal());
		/*	Iterator itr = list.entrySet().iterator();
			while (itr.hasNext()) {
				Map.Entry map1 = (Map.Entry) itr.next();
				Employee ins = (Employee) map1.getValue();
			//	list1.add(ins);
				oos.writeObject(itr);	
			}*/
			for(Map.Entry<String, Employee> ent:list.entrySet())
			{
			/*	Employee em = ent.getValue();
				System.out.println(em);
				wri.write(em.toString());*/
				oos.writeObject(ent.getValue().toString());
				oos.writeUTF("\n");
				oos.flush();
				//oos.close();
			}
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}
