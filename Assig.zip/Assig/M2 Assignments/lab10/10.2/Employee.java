package com.cg.lab10;

public class Employee {
    int id;
    String name;
    double Salary;
    String designation;
    String insuranceScheme;
    public Employee() {
        super();
        this.id = 0;
        this.name = null;
        Salary = 0.0;
        this.designation = null;
        this.insuranceScheme = null;
    }
    public Employee(int id, String name, double salary, String designation, String insuranceScheme) {
        super();
        this.id = id;
        this.name = name;
        Salary = salary;
        this.designation = designation;
        this.insuranceScheme = insuranceScheme;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public double getSalary() {
        return Salary;
    }
    public void setSalary(double salary) {
        Salary = salary;
    }
    public String getDesignation() {
        double salary=this.getSalary();
        if(salary>5000 && salary < 20000)
            this.designation="system associate";
        else if(salary>=20000 && salary<40000)
            this.designation="programmer";
        else if(salary>40000)
            this.designation="manager";
        else
            this.designation="clerk";
        return designation;
    }
    public void setDesignation(String designation) {
        this.designation = designation;
    }
    public String getInsuranceScheme() {
        if(designation.equals("system associate"))
            this.insuranceScheme="Scheme C";
        else if(designation.equals("programmer"))
            this.insuranceScheme="Scheme B";
        else if(designation.equals("manager"))
            this.insuranceScheme="Scheme A";
        else
            this.insuranceScheme="No Scheme";
        
        return insuranceScheme;
    }
    public void setInsuranceScheme(String insuranceScheme) {
        this.insuranceScheme = insuranceScheme;
    }
    @Override
    public String toString() {
        return "Employee10_2 [id=" + id + ", name=" + name + ", Salary=" + Salary + ", designation=" + designation
                + ", insuranceScheme=" + insuranceScheme + "]";
    }
    
}
 