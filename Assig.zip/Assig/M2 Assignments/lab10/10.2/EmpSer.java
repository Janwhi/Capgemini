package com.cg.lab10;

public interface EmpSer {
	public abstract void addEmployeeDetails(Employee e1);

	public abstract void getEmployeeDetails(int id);

	public abstract void getInsuranceScheme(String s);

	public abstract void RemoveEmpDetails(int id);

	public abstract void DisplayAll();
}