package com.cpg.lab9.q2;

import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class ExceptionCheck {
	Employee emp = new Employee();

	@Test
	public void getIdtest() {
		Employee e1 = new Employee(101, null, 0.0, null, null);
		assertEquals(e1.getId(), 101);
	}

	@Test
	public void getnametest() {
		Employee e2 = new Employee(0, "Faiz", 0.0, null, null);
		assertEquals(e2.getName(), "Faiz");
	}

	@Test
	public void getsalarytest() {
//		Employee e1 = new Employee();
//		Employee e3 = new Employee(1000, "Faiz", 2000, "Analyst", "Scheme A");
		Employee e1 = new Employee(1001, "kannan", 2500.00, "acv", "asd");
	}
	
		
	}


