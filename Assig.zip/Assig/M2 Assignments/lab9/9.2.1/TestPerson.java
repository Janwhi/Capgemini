package com.cpg.lab9;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestPerson {

	Person p = new Person("Faiz","Ahmad",'M',"09-10-1996");
	@Test
	public void getfirstnametest() {
		assertEquals(p.getFirstName(), "Faiz");
		
	}
	@Test
	public void getlastnametest() {
		assertEquals(p.getLastName(), "Ahmad");
		
	}
	@Test
	public void getgendertest() {
		assertEquals(p.getGender(), 'M');
		
	}
	@Test
	public void getdateofbirthtest() {
		assertEquals(p.getDateofbirth(), "09-10-1996");
		
	}

}
