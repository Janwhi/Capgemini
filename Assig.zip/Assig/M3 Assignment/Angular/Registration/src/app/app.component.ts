import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Registration';
ID: string;
name: string;
cost: number;
cat;
check;
isOnline;
isOnline1;
Mega;
Bazar;
Dmart;
Reliance;
validate() {
  alert(this.ID);
  alert(this.name);
  if (this.cost > 0) {
  alert(this.cost);
  }
  if (this.isOnline === 'yes') {
    alert(this.isOnline);
  }
  if (this.isOnline1 === 'no') {
    alert(this.isOnline1);
  }
  if (this.cat) {
    alert(this.cat);
  }
  if (this.Reliance) {
    alert('Reliance');
  }
  if (this.Dmart) {
    alert('DMart');
  }
  if (this.Mega) {
    alert('Mega store');
  }
  if (this.Bazar) {
    alert('Big bazar');
  }
}
}
