package com.cg.lab10;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import oracle.jdbc.OracleConnection;

public class Service implements EmpSer {
	Connection conn = null;
	String driverName = "oracle.jdbc.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:XE";
	String user = "yash", pass = "yash";

	public Connection getConnection() {
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			conn = (OracleConnection) DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	@Override
	public void addEmployeeDetails(Employee e1) {
		conn = getConnection();
		String st = "insert into EmpDetails values(?,?,?,?,?)";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(st);
			ps.setInt(1, e1.getId());
			ps.setString(2, e1.getName());
			ps.setDouble(3, e1.getSalary());
			if (e1.getSalary() > 5000.00 && e1.getSalary() <= 20000.00) {
				ps.setString(4, "System Associate");
				ps.setString(5, "C");
			} else if (e1.getSalary() > 20000.00 && e1.getSalary() < 40000.00) {
				ps.setString(4, "Programmer");
				ps.setString(5, "B");
			} else if (e1.getSalary() >= 40000.00) {
				ps.setString(4, "Manager");
				ps.setString(5, "A");
			} else if (e1.getSalary() < 5000.00) {
				ps.setString(4, "Clerk");
				ps.setString(5, "No_Scheme");
			} else {
				ps.setString(4, null);
				ps.setString(5, null);
			}
			boolean r = ps.execute();
			if (r)
				System.out.println("unable to insert");
			else
				System.out.println("inserted");
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void getEmployeeDetails(int id) {
		conn = getConnection();
		String st = "Select * from EmpDetails where emp_id = ?";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(st);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				String str1 = "Emp ID\t Emp Name\tEmp Salary\tEmp Designation\tEmp Scheme\n";
				String str = rs.getInt(1) + "\t" + rs.getString(2) + "\t\t" + rs.getDouble(3) + "\t\t" + rs.getString(4)
						+ "\t\t" + rs.getString(5) + "\n";

				System.out.print(str1 + str);

			}
			ps.close();
		} catch (SQLException e) {
			e.getErrorCode();
		} finally {
			// ps.close();
		}
	}

	@Override
	public void getInsuranceScheme(String s) {
		conn = getConnection();
		String st = "Select * from EmpDetails where emp_scheme=?";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(st);
			ps.setString(1, s);
			ResultSet rs = ps.executeQuery();
			String str1 = "Emp ID\tEmp Name\tEmp Salary\tEmp Designation\tEmp Scheme\n";
			System.out.println(str1);
			while (rs.next()) {
				String str = rs.getInt(1) + "\t" + rs.getString(2) + "\t\t" + rs.getDouble(3) + "\t\t" + rs.getString(4)
						+ "\t\t" + rs.getString(5) + "\n";

				System.out.print(str);

			}
			ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void RemoveEmpDetails(int id) {
		conn = getConnection();
		String st = "Delete from EmpDetails where emp_id=?";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(st);
			ps.setInt(1, id);
			boolean r = ps.execute();
			if (r)
				System.out.println("unable to remove");
			else
				System.out.println("Removed successfully");
			ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void DisplayAll() {
		conn = getConnection();
		String st = "select * from EmpDetails order by emp_id";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(st);
			ResultSet rs = ps.executeQuery();
			String str1 = "Emp ID\t Emp Name\t\tEmp Salary\t\tEmp Designation\t\tEmp Scheme";
			System.out.println(str1);
			while (rs.next()) {
				String str = String.format("\n %5d %-20s %-20s %-20s %-20s", rs.getInt(1), rs.getString(2),
						rs.getDouble(3), rs.getString(4), rs.getString(5));

				System.out.print(str);

			}
			ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}