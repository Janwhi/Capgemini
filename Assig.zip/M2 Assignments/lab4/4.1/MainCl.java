package com.cg.lab4;

public class MainCl {

	public static void main(String[] args) {
		
		Person smith = new Person("Smith", 39.0f);
		Person kathy = new Person("Kathy", 29.0f);
		Account hold1 = new Account(2000);
		Account hold2 = new Account(3000);
		hold1.deposite(2000);
		hold2.withdraw(2000);
		System.out.println("Balance for "+ hold1.accNum +" is " + hold1.getBalance());
		System.out.println("Balance for "+ hold2.accNum +" is " +hold2.getBalance());
		System.out.println();
		System.out.println(hold1);
		System.out.println();
		System.out.println(hold2);
		
		Savings_Account sc = new Savings_Account();
		Current_Account ca = new Current_Account();
		hold1.deposite(15000);
		System.out.println("Balance for "+ hold1.accNum +" is " + hold1.getBalance());
		ca.withdraw(36000);
		ca.withdraw(5000);
	}

}
