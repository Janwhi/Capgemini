//Lab2 2.5 enumeration for getting gender values.

package com.cg.lab2;

public class FirstEnum {
	public enum Gender{M,F};
}
