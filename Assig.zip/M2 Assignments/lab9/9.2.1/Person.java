package com.cpg.lab9;

public class Person {

	
	String FirstName;
	String LastName;
	char Gender;
	String dateofbirth;
	public Person(String firstName, String lastName, char gender, String dateofbirth) {
		super();
		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
		this.dateofbirth = dateofbirth;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public char getGender() {
		return Gender;
	}
	public void setGender(char gender) {
		Gender = gender;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	@Override
	public String toString() {
		return "Person [FirstName=" + FirstName + ", LastName=" + LastName + ", Gender=" + Gender + ", dateofbirth="
				+ dateofbirth + "]";
	}
	
	
}
