package com.cg.project11.models;

import java.sql.Date;
import java.time.LocalDate;

public class PurchaseDetails {
	private int purchaseId;
	private String custName;
	private String mailId;
	private String phoneNo;
	private Date perchaseDate;
	private String mobId;
	public PurchaseDetails() {
		super();
	//	this.purchaseId = purchaseId;
		this.custName = "";
		this.mailId = "";
		this.phoneNo = "";
	//	this.perchaseDate = perchaseDate;
		this.mobId = "";
	}
	public PurchaseDetails( String custName, String mailId, String phoneNo,String mobId) {
		super();
	//	this.purchaseId = purchaseId;
		this.custName = custName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
	//	this.perchaseDate = perchaseDate;
		this.mobId = mobId;
	}
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Date getPerchaseDate() {
		return perchaseDate;
	}
	public void setPerchaseDate(Date perchaseDate) {
		this.perchaseDate = perchaseDate;
	}
	public String getMobId() {
		return mobId;
	}
	public void setMobId(String mobId) {
		this.mobId = mobId;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId=" + purchaseId + ", custName=" + custName + ", mailId=" + mailId
				+ ", phoneNo=" + phoneNo + ", perchaseDate=" + perchaseDate + ", mobId=" + mobId + "]";
	}
	
	
}
