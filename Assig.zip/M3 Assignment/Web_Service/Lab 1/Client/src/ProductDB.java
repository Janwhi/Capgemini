
public interface ProductDB {

	public String availPruduct(String str);
}
