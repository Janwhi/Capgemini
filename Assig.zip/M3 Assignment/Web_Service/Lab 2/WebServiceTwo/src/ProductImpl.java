import java.util.List;

public interface ProductImpl {

	public void addProduct(String name,int id,double price);
}
