package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String usrname = request.getParameter("user_name");
		String pass = request.getParameter("user_pass");

		if (usrname.equals("admin") && pass.equals("admin")) {
			RequestDispatcher rd = request.getRequestDispatcher("Success.jsp");
			rd.forward(request, response);

		} else {
			response.sendRedirect("Login.jsp?errorMsg=Please enter the correct credentials!");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
