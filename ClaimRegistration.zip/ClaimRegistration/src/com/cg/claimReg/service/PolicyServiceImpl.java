package com.cg.claimReg.service;

import java.util.List;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.dao.AccountsDao;
import com.cg.claimReg.dao.AccountsDaoImpl;
import com.cg.claimReg.dao.ClaimDao;
import com.cg.claimReg.dao.ClaimDaoImpl;
import com.cg.claimReg.dao.PolicyDetailsDao;
import com.cg.claimReg.dao.PolicyDetailsDaoImpl;
import com.cg.claimReg.model.Policy;
import com.cg.claimReg.model.PolicyDetails;



public class PolicyServiceImpl implements PolicyService {
	ClaimDao claimDao = new ClaimDaoImpl();
	PolicyDetailsDao policyDetails = new PolicyDetailsDaoImpl();
	AccountsDao account = new AccountsDaoImpl();
	

	public List<Policy> viewPolicies(long accountNo) throws ClaimException {
		return claimDao.viewPolicies(accountNo);
	}


	public boolean isPolicyExists(long policyNo, List<Policy> policies)
			throws ClaimException {
		boolean flag = false;

		for (Policy policy : policies) {
			if (policy.getPolicyNo() == policyNo) {
				flag = true;
			}
		}
		return flag;
	}
	

	public int insertPolicyDetails(PolicyDetails details) throws ClaimException {
		return policyDetails.insertPolicyDetails(details);
	}
	

	public List<Policy> getPolicyList(String userName) throws ClaimException {
	
		return account.getPolicyList(userName);
	}
	
	

	public boolean isPolicyNo(long policyNo) throws ClaimException {
		
		return claimDao.checkPolicyNo(policyNo);
	}

	public List<Policy> getPolicyList() throws ClaimException {
		
		return claimDao.getPolicyList();
	}


	public List<PolicyDetails> getPolicyDetails(long claimNo)
			throws ClaimException {
		
		return policyDetails.getPolicyDetails(claimNo);
	}
}
