package com.cg.claimReg.service;

import java.util.regex.Pattern;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.dao.LoginDao;
import com.cg.claimReg.dao.LoginDaoImpl;
import com.cg.claimReg.dao.ProfileCreationDao;
import com.cg.claimReg.dao.ProfileCreationDaoImpl;
import com.cg.claimReg.model.UserRole;



public class UserServiceImpl implements UserService{
	
	LoginDao dao = new LoginDaoImpl();
	ProfileCreationDao creation = new ProfileCreationDaoImpl();
	@Override
	public Boolean validateUser(UserRole user) throws ClaimException {

		return dao.validateUser(user);
	}
	@Override
	public String getRoleCode(UserRole user) throws ClaimException {
		return dao.getRoleCode(user);
	}

	@Override
	public boolean isValidUsername(String username) throws ClaimException {
		String regEx = "[A-Z]{1}[a-zA-Z0-9]{3,19}";
		return Pattern.matches(regEx, username);
	}

	@Override
	public boolean isValidPassword(String profilePassword)
			throws ClaimException {
		String regEx = "[A-Z]{1}[a-zA-z0-9@$%*#_-]{6,11}";
		return Pattern.matches(regEx, profilePassword);
	}

	@Override
	public boolean isValidRoleCode(String roleCode) throws ClaimException {
		boolean roleFlag = false;
		if (roleCode.equals("CLAIM ADJUSTER") || roleCode.equals("CLAIM HANDLER")
				|| roleCode.equals("INSURED"))
			roleFlag = true;
		return roleFlag;

	}

	@Override
	public int profileCreation(UserRole newUser) throws ClaimException {
		return creation.profileCreation(newUser);
	}
}
