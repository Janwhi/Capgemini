package com.cg.claimReg.service;

import java.util.List;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.Accounts;
import com.cg.claimReg.model.Claim;
import com.cg.claimReg.model.ClaimQuestions;


public interface ClaimService {

	boolean isValidClaimReason(String claimReason) throws ClaimException;

	boolean isValidCity(String City) throws ClaimException;

	boolean isValidLocation(String Location)throws ClaimException;

	boolean isValidState(String State) throws ClaimException;

	boolean isValidZip(long Zip) throws ClaimException;

	boolean isValidClaimType(String claimType) throws ClaimException;

	long insertClaimDetails(Claim claim) throws ClaimException;

	List<Claim> getAllClaims() throws ClaimException;

	List<ClaimQuestions> getAllClaimQuestions(long policyNo)
			throws ClaimException;

	List<Claim> getAllclaimReport() throws ClaimException;

	List<Claim> showInsuredClaims(String userName) throws ClaimException;

	List<Accounts> getAllAccounts(String userName) throws ClaimException;

	List<Claim> showAgentClaims(Long policyNo) throws ClaimException;

	Claim getClaimDetails(long claimNo) throws ClaimException;

	String getClaimQuestions(int questionId) throws ClaimException;

	List<Claim> showAgentCustomerClaim(long accountNo)
			throws ClaimException;

}
