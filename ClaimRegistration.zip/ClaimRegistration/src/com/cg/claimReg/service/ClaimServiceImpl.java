package com.cg.claimReg.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.dao.AccountsDao;
import com.cg.claimReg.dao.AccountsDaoImpl;
import com.cg.claimReg.dao.ClaimDao;
import com.cg.claimReg.dao.ClaimDaoImpl;
import com.cg.claimReg.dao.ClaimQuestionsDao;
import com.cg.claimReg.dao.ClaimQuestionsDaoImpl;
import com.cg.claimReg.dao.LoginDao;
import com.cg.claimReg.dao.LoginDaoImpl;
import com.cg.claimReg.dao.PolicyDetailsDao;
import com.cg.claimReg.dao.PolicyDetailsDaoImpl;
import com.cg.claimReg.dao.ProfileCreationDao;
import com.cg.claimReg.dao.ProfileCreationDaoImpl;
import com.cg.claimReg.dao.ReportGenerationDao;
import com.cg.claimReg.dao.ReportGenerationDaoImpl;
import com.cg.claimReg.model.Accounts;
import com.cg.claimReg.model.Claim;
import com.cg.claimReg.model.ClaimQuestions;

public class ClaimServiceImpl implements ClaimService {
	LoginDao dao = new LoginDaoImpl();
	ClaimDao claimDao = new ClaimDaoImpl();
	ClaimQuestionsDao claimQuestion = new ClaimQuestionsDaoImpl();
	ProfileCreationDao creation = new ProfileCreationDaoImpl();
	PolicyDetailsDao policyDetails = new PolicyDetailsDaoImpl();
	ReportGenerationDao report = new ReportGenerationDaoImpl();
	AccountsDao account = new AccountsDaoImpl();

	public boolean isValidClaimReason(String claimReason) throws ClaimException {
		String regEx = "[A-Z]{1}[a-zA-Z ]{2,29}";
		return Pattern.matches(regEx, claimReason);
	}

	@Override
	public boolean isValidCity(String City) throws ClaimException {
		String regEx = "[A-Z]{1}[a-zA-Z ]{2,14}";
		return Pattern.matches(regEx, City);
	}

	public boolean isValidLocation(String Location) throws ClaimException {
		String regEx = "[A-Z0-9]{1}[a-zA-Z0-9 ,]{2,39}";
		return Pattern.matches(regEx, Location);
	}

	public boolean isValidState(String State) throws ClaimException {
		String regEx = "[A-Z]{1}[a-zA-Z ]{2,14}";
		return Pattern.matches(regEx, State);
	}

	public boolean isValidZip(long Zip) throws ClaimException {
		String regEx = "[1-9]{1}[0-9]{4}";
		return Pattern.matches(regEx, String.valueOf(Zip));
	}

	public boolean isValidClaimType(String claimType) throws ClaimException {
		boolean claimTypeFlag = false;
		if (claimType.equalsIgnoreCase("Accident") || claimType.equalsIgnoreCase("Property damage")
				|| claimType.equalsIgnoreCase("Natural Calamities") || claimType.equalsIgnoreCase("Theft"))
			claimTypeFlag = true;
		return claimTypeFlag;
	}

	public long insertClaimDetails(Claim claim) throws ClaimException {
		return claimDao.insertClaimDetails(claim);
	}

	public List<Claim> getAllClaims() throws ClaimException {
		return claimDao.getAllClaims();
	}

	@Override
	public List<ClaimQuestions> getAllClaimQuestions(long policyNo) throws ClaimException {
		return claimQuestion.getAllClaimQuestions(policyNo);
	}

	@Override
	public List<Claim> getAllclaimReport() throws ClaimException {
		return report.getAllclaimReport();
	}

	@Override
	public List<Claim> showInsuredClaims(String userName) throws ClaimException {
		return claimDao.showInsuredClaims(userName);
	}

	@Override
	public List<Accounts> getAllAccounts(String userName) throws ClaimException {
		return account.getAllAccounts(userName);
	}

	@Override
	public List<Claim> showAgentClaims(Long policyNo) throws ClaimException {
		return claimDao.showAgentClaims(policyNo);
	}

	@Override
	public Claim getClaimDetails(long policyNo) throws ClaimException {

		return claimDao.getClaimDetails(policyNo);
	}

	@Override
	public String getClaimQuestions(int questionId) throws ClaimException {
		return claimQuestion.getClaimQuestions(questionId);
	}

	@Override
	public List<Claim> showAgentCustomerClaim(long accountNo) throws ClaimException {
		return claimDao.showAgentCustomerClaim(accountNo);
	}

}
