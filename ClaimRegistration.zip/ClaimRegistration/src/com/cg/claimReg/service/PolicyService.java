package com.cg.claimReg.service;

import java.util.List;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.Policy;
import com.cg.claimReg.model.PolicyDetails;


public interface PolicyService {
	List<Policy> viewPolicies(long accountNo) throws ClaimException;

	boolean isPolicyExists(long policyNo, List<Policy> policies)
			throws ClaimException;

	int insertPolicyDetails(PolicyDetails details) throws ClaimException;

	List<Policy> getPolicyList(String userName) throws ClaimException;

	boolean isPolicyNo(long policyNo) throws ClaimException;

	List<Policy> getPolicyList() throws ClaimException;

	List<PolicyDetails> getPolicyDetails(long claimNo)
			throws ClaimException;

}
