package com.cg.claimReg.role;

import java.util.ArrayList;
import java.util.List;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.Claim;
import com.cg.claimReg.service.ClaimService;
import com.cg.claimReg.service.ClaimServiceImpl;



public class ViewClaim {
	ClaimService service = new ClaimServiceImpl();

	public void showClaim() throws ClaimException {
		List<Claim> claims = new ArrayList<>();
		claims = service.getAllClaims();

		if (!claims.isEmpty()) {
			System.out.println();
			System.out.printf("%10s %20s %20s %20s %20s %20s %20s %20s",
					"CLAIM NO", "CLAIM REASON", "LOCATION ",
					" CITY", "STATE", " ZIP",
					"CLAIM TYPE", "POLICY NO");
			for (Claim claim2 : claims) {
				System.out.println();
				System.out.printf("%10s %20s %20s %20s %20s %20s %20s %20s\n",
						claim2.getClaimNo(), claim2.getClaimReason(),
						claim2.getLocation(),
						claim2.getCity(), claim2.getState(),
						claim2.getZip(), claim2.getClaimType(),
						claim2.getPolicyNo());
			}
		} else {
			System.err.println("No Claims Available in Database");
		}

	}

	public void showInsuredClaim(String userName) throws ClaimException {

		List<Claim> claims = new ArrayList<>();
		claims = service.showInsuredClaims(userName);

		if (!claims.isEmpty()) {

			System.out.println();
			System.out.printf("%10s %20s %20s %20s %20s %20s %20s %20s",
					"CLAIM NO", "CLAIM REASON", "LOCATION ",
					" CITY", "STATE", " ZIP","CLAIM TYPE", "POLICY NO");

			for (Claim claim2 : claims) {
				System.out.println();
				System.out.printf("%10s %20s %20s %20s %20s %20s %20s %20s\n",
						claim2.getClaimNo(), claim2.getClaimReason(),
						claim2.getLocation(),
						claim2.getCity(), claim2.getState(),
						claim2.getZip(), claim2.getClaimType(),
						claim2.getPolicyNo());

			}

		} else {
			System.err.println("No Claims Available in Database");
		}
	}

	public void showCustomerClaim(Long policyNumber) throws ClaimException {
		List<Claim> claims = new ArrayList<>();
		claims = service.showAgentClaims(policyNumber);

		if (!claims.isEmpty()) {
			
			for (Claim claim2 : claims) {
				System.out.println(claim2);

			}
		}
		else{
			System.err.println("No claims for policy number:"+policyNumber);
		}

	}

	public void showAgentCustomerClaim(long accountNumber)
			throws ClaimException {
		List<Claim> claims = new ArrayList<>();
		claims = service.showAgentCustomerClaim(accountNumber);

		if (!claims.isEmpty()) {
			
			System.out.println();
			System.out.printf("%10s %20s %20s %20s %20s %20s %20s %20s",
					"CLAIM NO", "CLAIM REASON", "LOCATION ",
					" CITY", "STATE", " ZIP","CLAIM TYPE", "POLICY NO");

			for (Claim claim2 : claims) {
				System.out.println();
				System.out.printf("%10s %20s %20s %20s %20s %20s %20s %20s",
						claim2.getClaimNo(), claim2.getClaimReason(),
						claim2.getLocation(),
						claim2.getCity(), claim2.getState(),
						claim2.getZip(), claim2.getClaimType(),
						claim2.getPolicyNo());

			}

		}
		else{
			System.err.println("No claims for the customer with account number:"+accountNumber);
		}

	}

}
