package com.cg.claimReg.role;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.main.CrMain;
import com.cg.claimReg.model.Accounts;
import com.cg.claimReg.model.Policy;
import com.cg.claimReg.model.UserRole;
import com.cg.claimReg.service.ClaimService;
import com.cg.claimReg.service.ClaimServiceImpl;
import com.cg.claimReg.service.PolicyService;
import com.cg.claimReg.service.PolicyServiceImpl;



public class ClaimHandler {

	Scanner scanner = null;
	ClaimService service = new ClaimServiceImpl();
	PolicyService policyService = new PolicyServiceImpl();
	ViewClaim viewClaim = new ViewClaim();

	public void agentMethods(UserRole user) throws ClaimException {

		boolean insuredFlag = false;
		boolean agentChoiceFlag = false;
		int agentChoice = 0;
		do {
			scanner = new Scanner(System.in);
			List<Accounts> accounts = new ArrayList<>();

			accounts = service.getAllAccounts(user.getUserName());
			if (accounts.isEmpty()) {
				System.out.println("You don't have any customers");
				insuredFlag = true;
				do {
					scanner = new Scanner(System.in);
					System.out.println("Enter 1 to exit and 2 to logout");
					try {
						agentChoice = scanner.nextInt();
						switch (agentChoice) {
						case 1:
							System.err.println("Thank you, visit again.");
							System.exit(0);
							break;
						case 2:
							CrMain.login();
							agentChoiceFlag = true;
							break;
						default:
							agentChoiceFlag = false;
							System.err.println("Choose 1 or 2");
							break;
						}

					} catch (InputMismatchException e) {
						agentChoiceFlag = false;
						System.out.println("Enter only digits");
					}

				} while (!agentChoiceFlag);
			} else {
				System.out.println("\n\nYour customers details:");
				System.out.println();
				System.out.printf("%10s %20s %20s", "Account No",
						"Insured Name", "User Name");
				System.out.println();
				for (Accounts accounts2 : accounts) {
					System.out
							.printf("%10s %20s %20s\n",
									accounts2.getAccountNo(),
									accounts2.getInsuredName(),
									accounts2.getUserName());
				}

				scanner = new Scanner(System.in);
				System.out.println();
				System.out
						.println("-----CLAIM HANDLER-----");
				System.out.println();
				System.out.println("1.Claim Creation");
				System.out.println("2.View Claim");
				System.out.println("3.Exit");
				System.out.println("4.LOGOUT");
				System.out.println("Enter your Choice");
				try {
					int choice = scanner.nextInt();
					switch (choice) {

					case 1:

						List<Policy> policies = new ArrayList<>();

						boolean accountFlag = false;
						boolean checkFlag = false;
						long accountNo = 0l;
						do {
							scanner = new Scanner(System.in);
							System.out
									.println("Enter Account No or enter 0 to go back to previous menu:");
							try {
								accountNo = scanner.nextLong();
								if (accountNo == 0l) {
									accountFlag = true;
									insuredFlag = false;
								} else {
									for (Accounts account : accounts) {
										if (account.getAccountNo() == accountNo) {
											checkFlag = true;
										}
									}

									if (checkFlag == false) {
										System.err
												.println("Invalid Account no. Please select account no from the list");
										accountFlag = false;

									} else {
										accountFlag = true;
										policies = policyService
												.viewPolicies(accountNo);

										if (policies.isEmpty()) {
											accountFlag = false;
											System.err
													.println("No Policy for Account No: "
															+ accountNo);
										} else {
											System.out.println();
											System.out.printf("%10s %20s %20s",
													"Policy No",
													"Policy Premium",
													"Policy Type");
											for (Policy policy : policies) {
												System.out.println();
												System.out
														.printf("%10s %20s %20s\n",
																policy.getPolicyNo(),
																policy.getPolicyPremium(),
																policy.getPolicyType());
											}

											boolean policyFlag = false;
											long policyNo = 0l;
											do {
												scanner = new Scanner(System.in);
												System.out
														.println("\nSelect Policy No from above list or enter 0 to go back to previous menu: ");

												try {
													policyNo = scanner
															.nextLong();

													if (policyNo == 0l) {
														policyFlag = true;
														accountFlag = true;
														insuredFlag = false;
													} else {

														boolean isPolicyExists = policyService
																.isPolicyExists(
																		policyNo,
																		policies);

														if (!isPolicyExists) {
															policyFlag = false;
															System.err
																	.println("Given Policy No does not matched, Select Policy No from above List");
														} else {
															policyFlag = true;
															boolean checkPolicyFlag = policyService
																	.isPolicyNo(policyNo);
															if (checkPolicyFlag == false) {
																ClaimCreation claimCreation = new ClaimCreation();
																claimCreation
																		.createNewClaim(
																				policyNo,
																				user);
															} else {
																System.err
																		.println("Claim already created for the policy no:"
																				+ policyNo);
																policyFlag = false;

															}

														}

													}
												} catch (InputMismatchException e) {
													policyFlag = false;
													System.err
															.println("Policy No should be digits only");
												}

											} while (!policyFlag);

										}
									}

								}
							} catch (InputMismatchException e) {
								accountFlag = false;
								System.err
										.println("AccountNo should be digits only");
							}
						} while (!accountFlag);

						break;

					case 2:

						boolean claimFlag = false;
						int claimChoice = 0;
						boolean isPolicyExistFlag = false;

						do {

							System.out.println("1.View All Claims");
							System.out.println("2.View Claim of a specific customer");
							System.out.println("3. Go back to previous menu");
							scanner = new Scanner(System.in);

							try {
								System.out.println("Enter a choice:");
								claimChoice = scanner.nextInt();
								claimFlag = true;
								switch (claimChoice) {
								case 1:
									for (Accounts account : accounts) {
										//isPolicyExistFlag = false;
										policies = policyService.viewPolicies(account
												.getAccountNo());
										if(policies.isEmpty())
										{
											isPolicyExistFlag = true;
										}
										
											/*System.out.println("Your customer "+account.getInsuredName()+" does not have any policies");*/
										else{
											System.out.println("Claims for account number:"+account.getAccountNo());
											System.out.println();
										for (Policy policy2 : policies) {

											ViewClaim viewClaim = new ViewClaim();
											viewClaim.showCustomerClaim(policy2
													.getPolicyNo());
											
										}
										isPolicyExistFlag = false;
										
										}
										if(isPolicyExistFlag)
											System.err.println("Customer with "+account.getAccountNo()+" does not have any claims\n");
											

									}
									break;
								case 2:
									boolean customerFlag = false;
									checkFlag = false;
									do {
										System.out.println();
										System.out.printf("%10s %20s %20s",
												"Account No",
												"Insured Name", "User Name");
										System.out.println();
										for (Accounts accounts2 : accounts) {
											System.out
													.printf("%10s %20s %20s\n",
															accounts2
																	.getAccountNo(),
															accounts2
																	.getInsuredName(),
															accounts2
																	.getUserName());
										}
										scanner = new Scanner(System.in);
										try {
											System.out
													.println("Enter Account no of your customer or enter 0 to go back to previous menu:");
											accountNo = scanner.nextLong();
											if (accountNo == 0l) {
												customerFlag = true;
												claimFlag = false;
											} else {
												for (Accounts account : accounts) {
													if (account
															.getAccountNo() == accountNo) {
														checkFlag = true;
													}

												}
												if (checkFlag == false) {
													System.err
															.println("Invalid Account no. Please select account no from the list");
													customerFlag = false;

												} else {
													
													customerFlag = true;
													viewClaim
															.showAgentCustomerClaim(accountNo);
												}

											}
										} catch (InputMismatchException e) {
											customerFlag = false;
											System.err
													.println("Digits only allowed.");
										}

									} while (!customerFlag);

									break;
								case 3:
									claimFlag = true;
									insuredFlag = false;
									break;
								default:
									System.err
											.println("Choose between 1-3 only.");
									claimFlag = false;
									break;
								}
							} catch (InputMismatchException e) {
								claimFlag = false;
								System.err.println("Digits only allowed.");

							}

						} while (!claimFlag);

						break;

					case 3:
						System.err.println("Thank you,visit again");
						System.exit(0);
						break;

					case 4:
						System.err
								.println("You have successfully logged off from your account.");
						insuredFlag = true;
						CrMain.login();
						break;
					default:
						insuredFlag = false;
						System.err.println("Choice should be between 1 to 4");
					}

				} catch (InputMismatchException e) {
					insuredFlag = false;
					System.err.println("Enter digits only");
				}

			}
		} while (!insuredFlag);
	}
}
