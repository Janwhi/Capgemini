package com.cg.claimReg.role;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.Claim;
import com.cg.claimReg.model.PolicyDetails;
import com.cg.claimReg.model.UserRole;
import com.cg.claimReg.service.ClaimService;
import com.cg.claimReg.service.ClaimServiceImpl;
import com.cg.claimReg.service.PolicyService;
import com.cg.claimReg.service.PolicyServiceImpl;

public class ReportGeneration {
	ClaimService service = new ClaimServiceImpl();
	ClaimAdjuster adjuster = new ClaimAdjuster();
	PolicyService policyService = new PolicyServiceImpl();
	Scanner scanner = new Scanner(System.in);
	UserRole user = new UserRole();
	boolean reportFlag = false;

	public void generateReport() throws ClaimException {
		System.out
				.println("-----Report Generation Screen-----");

		List<Claim> claimReport = new ArrayList<>();

		claimReport = service.getAllclaimReport();
		if (claimReport.isEmpty()) {
			System.out.println("No Claims Available");
			adjuster.admin(user);
		} else {
			System.out.println();
			System.out.printf("%10s %20s %20s %20s", "POLICY_NO",
					"CLAIM_NO", "CLAIM REASON", "CLAIM TYPE");
			for (Claim claim : claimReport) {

				System.out.println();
				System.out.printf("%10s %20s %20s %30s\n",
						claim.getPolicyNo(), claim.getClaimNo(),
						claim.getClaimReason(), claim.getClaimType());
			}
			System.out.println();
			do {
				scanner = new Scanner(System.in);
				try {

					System.out
							.println("Enter policy number to view detailed report or enter 0 to go back to previous menu:");

					long policyNo = scanner.nextLong();
					if (policyNo == 0l) {
						adjuster.admin(user);
					}
					for (Claim claims : claimReport) {
						if (policyNo == claims.getPolicyNo()) {
							Claim claim = new Claim();
							
							claim = service.getClaimDetails(policyNo);
							System.out
									.println("-----Detailed view of claim with policy no:"
											+ policyNo
											+ "------");
							System.out.println();
							System.out.println(claim);
							List<PolicyDetails> list = new ArrayList<PolicyDetails>();
							list = policyService.getPolicyDetails(policyNo);

							for (PolicyDetails policyDetails : list) {
								int questionId = policyDetails.getQuestionID();

								String question = service
										.getClaimQuestions(questionId);
								System.out.println(question);
								System.out.println(policyDetails.getAnswer());
							}
							reportFlag = true;
							break;
						}
					}

					if (!reportFlag) {
						System.err
								.println("Claim for the policy number has not been created.Please enter a different policy number from the list.");
					}
				} catch (InputMismatchException e) {
					reportFlag = false;
					System.err.println("Digits only allowed");
				}

			} while (!reportFlag);
		}

	}

}
