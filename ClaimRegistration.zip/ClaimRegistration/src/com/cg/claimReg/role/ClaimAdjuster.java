package com.cg.claimReg.role;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.main.CrMain;
import com.cg.claimReg.model.Policy;
import com.cg.claimReg.model.UserRole;
import com.cg.claimReg.service.ClaimService;
import com.cg.claimReg.service.ClaimServiceImpl;
import com.cg.claimReg.service.PolicyService;
import com.cg.claimReg.service.PolicyServiceImpl;

public class ClaimAdjuster {

	ClaimService service = new ClaimServiceImpl();
	PolicyService policyService = new PolicyServiceImpl();
	Scanner scanner = null;

	public void admin(UserRole user) throws ClaimException {
		boolean adminFlag = false;
		do {
			scanner = new Scanner(System.in);
			System.out.println();
			System.out.println("-----CLAIM ADJUSTER-----");
			System.out.println();
			System.out.println("1.New Profile Creation");
			System.out.println("2.Claim Creation");
			System.out.println("3.View Claim");
			System.out.println("4.Report Generation");
			System.out.println("5.LOGOUT");
			System.out.println("6.Exit");
			System.out.println("Enter your Choice");
			try {
				int choice = scanner.nextInt();
				switch (choice) {
				case 1:
					ProfileCreation profileCreation = new ProfileCreation();
					profileCreation.createNewProfile(user);
					break;

				case 2:
					System.out.println();
					System.out.printf("%10s %20s %20s %20s", "Policy No",
							"Account No", "Policy Premium", "Policy Type");
					
					List<Policy> policiesList = new ArrayList<Policy>();
					policiesList = policyService.getPolicyList();

					for (Policy policy : policiesList)  {
						System.out.println();
						System.out.printf("%10s %20s %20s %20s",
								policy.getPolicyNo(),
								policy.getAccountNo(),
								policy.getPolicyPremium(),
								policy.getPolicyType());
					}
					System.out.println();
					boolean policyFlag = false;
					long policyNo = 0l;
					do {
						scanner = new Scanner(System.in);
						System.out
								.println("Select Policy No from above list or enter 0 to go back to previous menu:");

						try {
							policyNo = scanner.nextLong();
							if (policyNo == 0l) {
								policyFlag = true;
								adminFlag = false;
							}
							else {
								boolean isPolicyExists = policyService
										.isPolicyExists(policyNo,
												policiesList);
								if (!isPolicyExists) {
									policyFlag = false;
									System.err
											.println("Given Policy No does not matched, Select Policy No from above List");
								} 
								else {
									policyFlag = true;
									boolean checkFlag = policyService.isPolicyNo(policyNo);
									if (checkFlag == false) {
										ClaimCreation claimCreation = new ClaimCreation();
										claimCreation.createNewClaim(
												policyNo, user);
									} else {
										System.err
												.println("Claim already created for the policy no:"
														+ policyNo);
									}
								}
							}
						} 
						catch (InputMismatchException e) {
							policyFlag = false;
							System.err.println("Policy No should be digits only");
						}
					} 
					while (!policyFlag);
					break;

				case 3:
					ViewClaim viewClaim = new ViewClaim();
					viewClaim.showClaim();
					break;

				case 4:
					ReportGeneration report = new ReportGeneration();
					report.generateReport();
					break;

				case 5:
					System.out
							.println("You have successfully logged off from your account");
					adminFlag = true;
					CrMain.login();
					break;

				case 6:
					System.err.println("Thank you,visit again");
					System.exit(0);
					break;

				default:
					adminFlag = false;
					System.err.println("Choice should be between 1 to 5");
				}

			} catch (InputMismatchException e) {
				adminFlag = false;
				System.err.println("Enter digits only");
			}

		} while (!adminFlag);

	}
}
