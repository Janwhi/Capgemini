package com.cg.claimReg.role;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.Claim;
import com.cg.claimReg.model.ClaimQuestions;
import com.cg.claimReg.model.PolicyDetails;
import com.cg.claimReg.model.UserRole;
import com.cg.claimReg.service.ClaimService;
import com.cg.claimReg.service.ClaimServiceImpl;
import com.cg.claimReg.service.PolicyService;
import com.cg.claimReg.service.PolicyServiceImpl;

public class ClaimCreation {

	Scanner scanner = null;
	ClaimService service = new ClaimServiceImpl();
	PolicyService policyService = new PolicyServiceImpl();
	ClaimAdjuster create = new ClaimAdjuster();
	ClaimHandler handler = new ClaimHandler();
	Insured insured = new Insured();

	public void createNewClaim(long policyNo, UserRole user)
			throws ClaimException {
		String claimReason = "";
		String Location = "";
		String City = "";
		String State = "";
		long Zip = 0;
		String claimType = "";

		boolean claimFlag = false;

		do {
			scanner = new Scanner(System.in);
			System.out
					.println("Enter claim reason or enter 0 to go back to previous menu");

			claimReason = scanner.nextLine();

			claimFlag = service.isValidClaimReason(claimReason);
			if (!claimFlag) {
				if (claimReason.equals("0")) {
					if (user.getRoleCode().equals("CLAIM HANDLER")) {
						handler.agentMethods(user);
					} 
					else if (user.getRoleCode().equals("CLAIM ADJUSTER")) {
						create.admin(user);
					}
					else {
						insured.insuredMethods(user);
					}
				}
				else {
					System.err
							.println("Claim reason first letter should be capital and range should be between 5-30.");
				}
			}
		} 
		while (!claimFlag);
		claimFlag = false;
		
		do {
			scanner = new Scanner(System.in);
			System.out
					.println("Enter location or enter 0 to go back to previous menu:");
			Location = scanner.nextLine();
			claimFlag = service.isValidLocation(Location);
			if (!claimFlag) {
				if (Location.equals("0")) {
					if (user.getRoleCode().equals("CLAIM HANDLER")) {
						handler.agentMethods(user);
					}
					else if (user.getRoleCode().equals("CLAIM ADJUSTER")) {
						create.admin(user);
					} 
					else {
						insured.insuredMethods(user);
					}
				}
				else {
					System.err
							.println("location should have first letter capital and range in between 5-40.");
				}
			}
		}
		while (!claimFlag);
		claimFlag = false;

		do {
			scanner = new Scanner(System.in);
			System.out
					.println("Enter city where occurred or enter 0 to go back to previous menu:");

			City = scanner.nextLine();
			claimFlag = service.isValidCity(City);
			if (!claimFlag) {
				if (City.equals("0")) {
					if (user.getRoleCode().equals("CLAIM HANDLER")) {
						handler.agentMethods(user);

					}
					else if (user.getRoleCode().equals("CLAIM ADJUSTER")) {
						create.admin(user);
					}
					else {
						insured.insuredMethods(user);
					}
				} 
				else {
					System.err
							.println("City first letter should be capital and range should be between 3-15.");
				}
			}
		} 
		while (!claimFlag);
		claimFlag = false;
		do {
			scanner = new Scanner(System.in);
			System.out
					.println("Enter state where occurred or enter 0 to go back to previous menu:");

			State = scanner.nextLine();
			claimFlag = service.isValidState(State);
			if (!claimFlag) {
				if (State.equals("0")) {
					if (user.getRoleCode().equals("CLAIM HANDLER")) {
						handler.agentMethods(user);

					}
					else if (user.getRoleCode().equals("CLAIM ADJUSTER")) {
						create.admin(user);
					}
					else {
						insured.insuredMethods(user);
					}
				} 
				else {
					System.err
							.println("state first letter should be capital and range should be between 3-15.");
				}
			}
		} 
		while (!claimFlag);
		claimFlag = false;
		
		do {
			scanner = new Scanner(System.in);
			try {
				System.out
						.println("Enter zip code of the area where occurred or enter 0 to go back to previous menu:");

				Zip = scanner.nextLong();
				claimFlag = service.isValidZip(Zip);
				if (!claimFlag) {
					if (Zip == 0l) {
						System.out.println(user.getRoleCode());
						if (user.getRoleCode().equals("CLAIM HANDLER")) {
							handler.agentMethods(user);
						} 
						else if (user.getRoleCode().equals("CLAIM ADJUSTER")) {
							create.admin(user);
						} 
						else {
							insured.insuredMethods(user);
						}
					} 
					else {
						System.err
								.println("Zip code should have exactly 5 digits.");
					}
				}
			} 
			catch (InputMismatchException e) {
				System.err.println("Digits only allowed.Enter again.");
				claimFlag = false;
			}
		}
		while (!claimFlag);
		claimFlag = false;

		do {
			scanner = new Scanner(System.in);
			try {
				System.out
						.println("Select a claim type or enter 0 to go back to previous menu:");
				System.out.println("1.Accident");
				System.out.println("2.Property damage");
				System.out.println("3.Natural Calamities");
				System.out.println("4.Theft");
				System.out.println("Enter your choice:");
				int choice = scanner.nextInt();

				switch (choice) {
				case 0:
					if (user.getRoleCode().equals("CLAIM HANDLER")) {
						handler.agentMethods(user);

					} else if (user.getRoleCode().equals("CLAIM ADJUSTER")) {
						create.admin(user);

					} else {
						insured.insuredMethods(user);
					}
					break;
				case 1:
					claimType = "Accident";
					claimFlag = true;
					break;
				case 2:
					claimType = "Property damage";
					claimFlag = true;
					break;
				case 3:
					claimType = "Natural Calamities";
					claimFlag = true;
					break;

				case 4:
					claimType = "Theft";
					claimFlag = true;
					break;
				default:
					System.err.println("Enter in range 1-4.");
					claimFlag = false;
					break;
				}
			} 
			catch (InputMismatchException e) {
				System.err.println("Enter digits only.");
				claimFlag = false;
			}
		} while (!claimFlag);

		Claim claim = new Claim(claimReason,Location, City,State, Zip, claimType, policyNo);
		boolean choiceFlag = false;
		long claimNo = 0l;
		scanner.nextLine();
		
		do {
			System.out
					.println("Enter YES to answer the questions and create claim, NO to exit the application and 0 to go back to previous menu");
			
			String choiceContinue = scanner.nextLine();
			if (choiceContinue.equals("0")) {
				if (user.getRoleCode().equals("CLAIM HANDLER")) {
					handler.agentMethods(user);
				} 
				else if (user.getRoleCode().equals("CLAIM ADJUSTER")) {
					create.admin(user);
				} 
				else {
					insured.insuredMethods(user);
				}
			}
			else if (choiceContinue.equalsIgnoreCase("NO")) {
				System.err.println("Thank you, visit again");
				System.exit(0);
			} 
			else if (choiceContinue.equalsIgnoreCase("YES")) {
				choiceFlag = true;
				PolicyDetails details = new PolicyDetails();
				int answerChoice = 0;
				boolean answerChoiceFlag = false;
				List<ClaimQuestions> questions = new ArrayList<ClaimQuestions>();
				questions = service.getAllClaimQuestions(policyNo);
				System.out.println("Please answer the given questions:");
				for (ClaimQuestions claimQuestions : questions) {

					details.setQuestionID(claimQuestions.getQuesId());
					details.setPolicyNo(policyNo);

					System.out.println(claimQuestions.getQuesDesc());
					System.out.println("1. " + claimQuestions.getQuesAns1()
							+ " 2." + claimQuestions.getQuesAns2());
					do {
						scanner = new Scanner(System.in);
						try {
							System.out
									.println("Enter 1 for yes or 2 for no or 0 to go back to previous menu:");
							answerChoice = scanner.nextInt();
							answerChoiceFlag = true;
							switch (answerChoice) {
							case 0:
								if (user.getRoleCode().equals("CLAIM HANDLER")) {
									handler.agentMethods(user);
								} 
								else if (user.getRoleCode().equals(
										"CLAIM ADJUSTER")) {
									create.admin(user);
								} 
								else {
									insured.insuredMethods(user);
								}
								break;
							case 1:
								details.setAnswer(claimQuestions.getQuesAns1());
								break;

							case 2:
								details.setAnswer(claimQuestions.getQuesAns2());
								break;

							default:
								System.err.println("Enter only 1 or 2");
								answerChoiceFlag = false;
								break;
							}
							policyService.insertPolicyDetails(details);
						}
						catch (InputMismatchException e) {
							answerChoiceFlag = false;
							System.err.println("Enter only 1 or 2");
						}
					} 
					while (!answerChoiceFlag);
				}
				claimNo = service.insertClaimDetails(claim);
			} 
			else {
				System.err.println("Enter YES or NO only");
				choiceFlag = false;
			}
		} 
		while (!choiceFlag);
		System.out.println("Claim Details Inserted With Claim No :"
				+ claimNo);
	}
}
