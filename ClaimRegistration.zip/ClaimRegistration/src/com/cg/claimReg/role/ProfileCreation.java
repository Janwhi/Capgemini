package com.cg.claimReg.role;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.UserRole;
import com.cg.claimReg.service.ClaimService;
import com.cg.claimReg.service.ClaimServiceImpl;
import com.cg.claimReg.service.UserService;
import com.cg.claimReg.service.UserServiceImpl;


public class ProfileCreation {

	Scanner scanner = null;
	ClaimService service = new ClaimServiceImpl();
	UserService userService = new UserServiceImpl();
	ClaimAdjuster adjust = new ClaimAdjuster();

	public void createNewProfile(UserRole user) throws ClaimException {
		String username = "";
		String profilePassword = "";
		String roleCode = "";
		boolean creationFlag = false;
		boolean insertFlag = false;
		int resultInsert = 0;
		do {
			scanner = new Scanner(System.in);
			System.out.print("Enter username or ");
			System.out.println("enter 0 to go back to previous menu");
			username = scanner.nextLine();
			creationFlag = userService.isValidUsername(username);
			if (!creationFlag) {
				if (username.equals("0"))
					adjust.admin(user);
				else
					System.err
							.println("Username first letter should be capital ,digits are allowed and should be in the range of 4 to 15 characters");
				}
			} while (!creationFlag);
			creationFlag = false;
			do {
				scanner = new Scanner(System.in);
				System.out.print("Enter password or ");
				System.out.println("enter 0 to go back to previous menu");
				profilePassword = scanner.nextLine();
				creationFlag = userService.isValidPassword(profilePassword);
				if (!creationFlag) {
					if (profilePassword.equals("0")) {
						adjust.admin(user);
					} 
					else {
						System.err
								.println("Password first letter should be capital, digits and special characters(@ ,$, %, *, #, _, -) are allowed,must be in the range of 7 to 12");
					}
				}
			} while (!creationFlag);
			creationFlag = false;
			do {
				scanner = new Scanner(System.in);
				try {
					System.out
							.println("Enter role code or enter 0 to go back to previous menu:");
					System.out.println("1.CLAIM ADJUSTER");
					System.out.println("2.CLAIM HANDLER");
					System.out.println("3.INSURED");
					System.out.println("Enter your choice:");
					int choice = scanner.nextInt();
					switch (choice) {
					case 0:
						adjust.admin(user);
						break;
					case 1:
						roleCode = "CLAIM ADJUSTER";
						creationFlag = true;
						break;
					case 2:
						roleCode = "CLAIM HANDLER";
						creationFlag = true;
						break;
					case 3:
						roleCode = "INSURED";
						creationFlag = true;
						break;
					default:
						System.err.println("Enter in the range 1-3.");
						creationFlag = false;
						break;
					}
					creationFlag = userService.isValidRoleCode(roleCode);
				} catch (InputMismatchException e) {
					creationFlag = false;
					System.err.println("Please enter digits only.");
				}
			} while (!creationFlag);

			UserRole newUser = new UserRole(username, profilePassword, roleCode);

			try {

				resultInsert = userService.profileCreation(newUser);
				if (resultInsert != 0)
					System.out
							.println("Profile created successfully with username :"
									+ username);
				insertFlag = true;

			}

			catch (ClaimException e) {
				insertFlag = false;
				System.err.println(e.getMessage());
			}
		while (!insertFlag);

	}

}
