package com.cg.claimReg.model;

import java.io.Serializable;

public class Claim implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long claimNo;
	private String claimReason;
	private String Location;
	private String City;
	private String State;
	private Long Zip;
	private String claimType;
	private Long policyNo;

	public Claim() {
		
	}
	public Claim(Long claimNo, String claimReason, String claimType,Long policyNo) {
		super();
		this.claimNo = claimNo;
		this.claimReason = claimReason;
		this.claimType = claimType;
		this.policyNo = policyNo;
	}

	public Claim(Long claimNo, String claimReason,String Location, 
			String City,String State, Long Zip, String claimType,Long policyNo) {
		super();
		this.claimNo= claimNo;
		this.claimReason = claimReason;
		this.Location = Location;
		this.City = City;
		this.State = State;
		this.Zip = Zip;
		this.claimType = claimType;
		this.policyNo = policyNo;
	}
	
	public Claim(String claimReason, String Location,String City, 
			String State, Long Zip,String claimType, Long policyNo) {
		super();
		this.claimReason = claimReason;
		this.Location = Location;
		this.City = City;
		this.State = State;
		this.Zip = Zip;
		this.claimType = claimType;
		this.policyNo = policyNo;
	}
	
	public Long getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(Long claimNo) {
		this.claimNo = claimNo;
	}

	public String getClaimReason() {
		return claimReason;
	}

	public void setClaimReason(String claimReason) {
		this.claimReason = claimReason;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String Location) {
		this.Location = Location;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String City) {
		this.City = City;
	}

	public String getState() {
		return State;
	}

	public void setState(String State) {
		this.State = State;
	}

	public Long getZip() {
		return Zip;
	}

	public void setZip(Long Zip) {
		this.Zip = Zip;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public Long getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(Long policyNo) {
		this.policyNo = policyNo;
	}

	@Override
	public String toString() {
		return "ClaimNo=" + claimNo + "\nClaimReason="+ claimReason + 
				"\nLocation="+ Location + "\nCity=" + City
				+ "\nState=" + State + "\nZip="+ Zip + 
				"\nClaimType=" + claimType + "\nPolicyNo="+ policyNo + "\n";
	}

}
