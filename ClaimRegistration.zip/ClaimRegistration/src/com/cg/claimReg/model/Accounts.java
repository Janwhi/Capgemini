package com.cg.claimReg.model;

import java.io.Serializable;

public class Accounts implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long accountNo;
	private String insuredName;
	private String userName;
	
	public Accounts() {
		
	}

	public Accounts(Long accountNo, String insuredName, String userName) {
		super();
		this.accountNo = accountNo;
		this.insuredName = insuredName;
		this.userName = userName;
	}

	public Long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "Accounts [accountNo=" + accountNo + ", insuredName="
				+ insuredName + ", userName=" + userName + "]";
	}
	
	

}