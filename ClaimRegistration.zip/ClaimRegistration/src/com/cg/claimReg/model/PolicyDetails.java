package com.cg.claimReg.model;

import java.io.Serializable;

public class PolicyDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private Long policyNo;
	private Integer questionID;
	private String answer;

	public PolicyDetails() {
		
	}

	public PolicyDetails(Long policyNo, Integer questionID, String answer) {
		super();
		this.policyNo = policyNo;
		this.questionID = questionID;
		this.answer = answer;
	}

	public Long getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(Long policyNo) {
		this.policyNo = policyNo;
	}

	public Integer getQuestionID() {
		return questionID;
	}

	public void setQuestionID(Integer questionID) {
		this.questionID = questionID;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

}
