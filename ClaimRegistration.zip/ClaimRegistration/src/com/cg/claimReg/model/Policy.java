package com.cg.claimReg.model;

public class Policy {
	private Long policyNo;
	private Double policyPremium;
	private Long accountNo;
	private String policyType;

	public Policy() {
		
	}

	public Policy(Long policyNo, Double policyPremium, Long accountNo,
			String policyType) {
		super();
		this.policyNo = policyNo;
		this.policyPremium = policyPremium;
		this.accountNo = accountNo;
		this.policyType = policyType;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public Long getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(Long policyNo) {
		this.policyNo = policyNo;
	}

	public Double getPolicyPremium() {
		return policyPremium;
	}

	public void setPolicyPremium(Double policyPremium) {
		this.policyPremium = policyPremium;
	}

	public Long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}

	@Override
	public String toString() {
		return "PolicyNo=" + policyNo + ", PolicyPremium="
				+ policyPremium + ", AccountNo=" + accountNo;
	}

}
