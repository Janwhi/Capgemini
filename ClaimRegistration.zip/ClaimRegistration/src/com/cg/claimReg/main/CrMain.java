package com.cg.claimReg.main;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.chainsaw.Main;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.UserRole;
import com.cg.claimReg.role.ClaimAdjuster;
import com.cg.claimReg.role.ClaimHandler;
import com.cg.claimReg.role.Insured;
import com.cg.claimReg.service.UserService;
import com.cg.claimReg.service.UserServiceImpl;




public class CrMain {
	static Logger logger = Logger.getLogger(Main.class);
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file configured..");
		login();
	}

	public static void login() {

		UserService us = new UserServiceImpl();
		Scanner sc = null;
		boolean loginFlag = false;
		String user_name = null;
		String password = null;
		
		do {
			System.out.println("-----Online Claim Registration System-----");

			sc = new Scanner(System.in);
			System.out.println("LOGIN:");
			System.out.println();
			
			do {
				System.out.println("User Name:");
				user_name = sc.nextLine();
				try {
					loginFlag = us.isValidUsername(user_name);
					}
				catch (ClaimException e) {
					System.err.println(e.getMessage());
				}
				if (!loginFlag)
					System.err.println("First letter should be capital and must be in the range of 7 to 12.");
				}
			
			while (!loginFlag);
			loginFlag = false;
			
			do {
				System.out.println("Enter Password:");
				password = sc.nextLine();
				try {
					loginFlag = us.isValidPassword(password);
					} 
				catch (ClaimException e) {
					System.err.println(e.getMessage());
				}
				if (!loginFlag)
					System.err.println("First letter should be capital.");
				}
			
			while (!loginFlag);
			loginFlag = false;
			
			UserRole user = new UserRole(user_name, password);

			try {
				Boolean result = us.validateUser(user);
				if (result) 
				{
					String role1 = us.getRoleCode(user);
					user.setRoleCode(role1);

					loginFlag = true;

					System.out.println("Access granted");
					System.out.println("Logged In As " + role1);
					System.out.println();
					System.out.println("Welcome " + user_name);
					
					switch (role1) {

					case "CLAIM ADJUSTER":
						ClaimAdjuster adjuster = new ClaimAdjuster();
						try {
							adjuster.admin(user);
						} catch (ClaimException e) {
							System.err.println(e.getMessage());
						}
						break;

					case "INSURED":
						Insured insured = new Insured();
						try {
							insured.insuredMethods(user);
						} catch (ClaimException e) {
							System.err.println(e.getMessage());
						}
						break;

					case "CLAIM HANDLER":
						ClaimHandler claimHandler = new ClaimHandler();
						try {
							claimHandler.agentMethods(user);
						} catch (ClaimException e) {
							System.err.println(e.getMessage());
						}
						break;
						
						default:
							break;
					}
				} 
				
				else {
					loginFlag = false;
					System.err.println("Unauthorized, Enter Again");
				}
			} 
			
			catch (ClaimException e) {
				loginFlag = false;
				System.err.println(e.getMessage());

			}
		} 
		while (!loginFlag);

		sc.close();

	}
}
		