package com.cg.claimReg.dao;

import java.util.List;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.PolicyDetails;




public interface PolicyDetailsDao {

	int insertPolicyDetails(PolicyDetails details)throws ClaimException;

	List<PolicyDetails> getPolicyDetails(long claimNo)throws ClaimException;

}
