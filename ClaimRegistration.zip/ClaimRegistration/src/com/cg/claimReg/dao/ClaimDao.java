package com.cg.claimReg.dao;

import java.util.List;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.Claim;
import com.cg.claimReg.model.Policy;

public interface ClaimDao {

	List<Policy> viewPolicies(long accountNo) throws ClaimException;

	long insertClaimDetails(Claim claim)throws ClaimException;

	List<Claim> getAllClaims()throws ClaimException;

	List<Claim> showInsuredClaims(String userName)throws ClaimException;

	boolean checkPolicyNo(long policyNo)throws ClaimException;

	List<Policy> getPolicyList()throws ClaimException;

	List<Claim> showAgentClaims(Long policyNo)throws ClaimException;

	Claim getClaimDetails(long claimNo)throws ClaimException;

	List<Claim> showAgentCustomerClaim(long accountNo)throws ClaimException;

}
