package com.cg.claimReg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.connection.JDBC;
import com.cg.claimReg.model.Claim;
import com.cg.claimReg.model.Policy;



public class ClaimDaoImpl implements ClaimDao {
	static Logger logger = Logger.getLogger(ClaimDaoImpl.class);

	@SuppressWarnings("unused")
	@Override
	public List<Policy> viewPolicies(long accountNo) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");

		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		List<Policy> policies = new ArrayList<>();
		connection = JDBC.getConnection();
		logger.info("connection object created");

		try {
			statement = connection.prepareStatement(QueryMapper.viewPolicy);
			logger.info("connection established..");
			statement.setLong(1, accountNo);

			set = statement.executeQuery();
			logger.info("resultset created");

			while (set.next()) {
				long policyNo = set.getLong("POLICY_NO");

				String policyType = set.getString("POLICY_TYPE");

				double premium = set.getDouble("POLICY_PREMIUM");

				long account_No = set.getLong("ACCOUNT_No");

				Policy policy = new Policy();
				policy.setPolicyNo(policyNo);
				policy.setPolicyPremium(premium);
				policy.setAccountNo(accountNo);
				policy.setPolicyType(policyType);

				policies.add(policy);
				logger.info("policy added to the list " + policy);
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new ClaimException("Sql exception" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return policies;

	}

	@Override
	public long insertClaimDetails(Claim claim) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		PreparedStatement preparedStatement = null;
		ResultSet set = null;
		Long result = 0l;
		connection = JDBC.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.insertClaimQuery);
			logger.info("connection established..");

			statement.setString(1, claim.getClaimReason());
	    	statement.setString(2, claim.getLocation());
			statement.setString(3, claim.getCity());
			statement.setString(4, claim.getState());
			statement.setLong(5, claim.getZip());
			statement.setString(6, claim.getClaimType());
			statement.setLong(7, claim.getPolicyNo());
			statement.executeUpdate();
			logger.info("claim added to the list ");

			preparedStatement = connection
					.prepareStatement(QueryMapper.getClaimNo);
			set = preparedStatement.executeQuery();
			set.next();
			result = set.getLong(1);

			connection.commit();

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();
				preparedStatement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return result;

	}

	@Override
	public List<Claim> getAllClaims() throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		List<Claim> claims = new ArrayList<>();
		connection = JDBC.getConnection();
		logger.info("connection object created");
		try {
			statement = connection.prepareStatement(QueryMapper.viewClaimQuery);
			logger.info("connection established..");
			set = statement.executeQuery();
			logger.info("resultset created");

			while (set.next()) {
				long claimNo = set.getLong("CLAIM_NO");
				String claimReason = set.getString("CLAIM_REASON");
				String location = set.getString("LOCATION");
				String city = set.getString("CITY");
				String state = set.getString("STATE");
				long zip = set.getLong("ZIP");
				String claimType = set.getString("CLAIM_TYPE");
				long policyNo = set.getLong("POLICY_NO");
				Claim claim = new Claim(claimNo, claimReason, location,
						city, state, zip, claimType, policyNo);
				claims.add(claim);
				logger.info("claim added to the list " + claim);

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());
				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return claims;

	}

	@Override
	public List<Claim> showInsuredClaims(String userName) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		PreparedStatement preparedStatement = null;
		ResultSet set = null;
		long accountNumber = 0l;
		long number = 0l;
		List<Long> policyNumbers = new ArrayList<>();
		List<Claim> claims = new ArrayList<>();
		connection = JDBC.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.getAccountNoQuery);
			logger.info("connection established..");

			statement.setString(1, userName);
			set = statement.executeQuery();
			logger.info("resultset created");
			boolean result = set.next();
			if (result == true) {
				accountNumber = set.getLong("ACCOUNT_NO");

				preparedStatement = connection
						.prepareStatement(QueryMapper.viewPolicy);
				preparedStatement.setLong(1, accountNumber);
				set = preparedStatement.executeQuery();
				logger.info("resultset created");
				while (set.next()) {
					number = set.getLong("POLICY_NO");
					policyNumbers.add(number);
				}

				for (Long policyNumber : policyNumbers) {

					statement = connection
							.prepareStatement(QueryMapper.viewInsuredClaimQuery);
					logger.info("connection established..");
					statement.setLong(1, policyNumber);
					set = statement.executeQuery();
					while (set.next()) {
						long claimNo = set.getLong("CLAIM_NO");
						String claimReason = set.getString("CLAIM_REASON");
						String location = set
								.getString("LOCATION");
						String city = set.getString("CITY");
						String state = set.getString("STATE");
						long zip = set.getLong("ZIP");
						String claimType = set.getString("CLAIM_TYPE");
						long policyNo = set.getLong("POLICY_NO");
						Claim claim = new Claim(claimNo, claimReason,location, city, state, 
								zip, claimType,policyNo);
						claims.add(claim);
						logger.info("policy added to the list " + claim);

					}

				}
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();
				/* preparedStatement.close(); */

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return claims;
	}
	public boolean checkPolicyNumber(long policyNo) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		boolean validate = false;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		connection = JDBC.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.validatePolicyNoQuery);
			logger.info("connection established..");
			statement.setLong(1, policyNo);

			set = statement.executeQuery();
			logger.info("resultset created");
			validate = set.next();

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Unauthorized" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return validate;
	}


	@Override
	public List<Policy> getPolicyList() throws ClaimException {
		logger.info("in ClaimDaoImpl  class");

		List<Policy> policies = new ArrayList<>();

		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		connection = JDBC.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.getPolicyListQuery);
			logger.info("connection established..");
			set = statement.executeQuery();
			logger.info("resultset created");

			while (set.next()) {
				long policyNo = set.getLong("policy_no");
				double premium = set.getDouble("policy_premium");
				long accountNo = set.getLong("account_no");
				String policyType = set.getString("policy_type");

				Policy policy = new Policy(policyNo, premium,
						accountNo, policyType);
				policies.add(policy);
				logger.info("policy added to the list " + policy);

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());
				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return policies;
	}

	@Override
	public List<Claim> showAgentClaims(Long policyNumber) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		// long accountNumber = 0l;
		// long number = 0l;
		// List<Long> policyNumbers = new ArrayList<>();
		List<Claim> claims = new ArrayList<>();
		connection = JDBC.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.viewAgentClaimQuery);
			logger.info("connection established..");
			statement.setLong(1, policyNumber);
			set = statement.executeQuery();
			logger.info("resultset created");
			while (set.next()) {
				long claimNumber = set.getLong("CLAIM_NUMBER");
				String claimReason = set.getString("CLAIM_REASON");
				String location = set.getString("ACCIDENT_LOCATION_STREET");
				String city = set.getString("ACCIDENT_CITY");
				String state = set.getString("ACCIDENT_STATE");
				long zip = set.getLong("ACCIDENT_ZIP");
				String claimType = set.getString("CLAIM_TYPE");
				long policyNumber1 = set.getLong("POLICY_NUMBER");
				Claim claim = new Claim(claimNumber, claimReason, location,
						city, state, zip, claimType, policyNumber1);
				claims.add(claim);
				logger.info("claim added to the list " + claim);

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return claims;
	}


	@Override
	public Claim getClaimDetails(long policyNumber) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		Claim claim = new Claim();
		connection = JDBC.getConnection();
		logger.info("connection object created");
		try {
			statement = connection.prepareStatement(QueryMapper.getClaimQuery);
			logger.info("connection established..");
			statement.setLong(1, policyNumber);
			set = statement.executeQuery();
			logger.info("resultset created");

			set.next();

			long claimNumber = set.getLong("CLAIM_NUMBER");
			String claimReason = set.getString("CLAIM_REASON");
			String location = set.getString("ACCIDENT_LOCATION_STREET");
			String city = set.getString("ACCIDENT_CITY");
			String state = set.getString("ACCIDENT_STATE");
			long zip = set.getLong("ACCIDENT_ZIP");
			String claimType = set.getString("CLAIM_TYPE");
			long policyNo = set.getLong("POLICY_NO");
			logger.info("policy added to the list ");

			claim = new Claim(claimNumber, claimReason, location, city, state,
					zip, claimType, policyNo);

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return claim;
	}
	@Override
	public List<Claim> showAgentCustomerClaim(long accountNumber)
			throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		long number = 0l;
		List<Long> policyNumbers = new ArrayList<>();
		List<Claim> claims = new ArrayList<>();
		connection = JDBC.getConnection();
		logger.info("connection object created");
		try {

			statement = connection.prepareStatement(QueryMapper.viewPolicy);
			logger.info("connection established..");
			statement.setLong(1, accountNumber);
			set = statement.executeQuery();
			logger.info("resultset created");
			while (set.next()) {
				number = set.getLong("POLICY_NO");
				policyNumbers.add(number);
			}

			for (Long policyNumber : policyNumbers) {

				statement = connection
						.prepareStatement(QueryMapper.viewInsuredClaimQuery);
				logger.info("connection established..");
				statement.setLong(1, policyNumber);
				set = statement.executeQuery();
				logger.info("resultset created");
				while (set.next()) {
					long claimNo = set.getLong("CLAIM_NO");
					String claimReason = set.getString("CLAIM_REASON");
					String location = set.getString("LOCATION");
					String city = set.getString("CITY");
					String state = set.getString("STATE");
					long zip = set.getLong("ZIP");
					String claimType = set.getString("CLAIM_TYPE");
					long policyNo = set.getLong("POLICY_NO");
					Claim claim = new Claim(claimNo, claimReason, location,
							city, state, zip, claimType, policyNo);
					claims.add(claim);

					logger.info("claim added to the list " + claim);

				}

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return claims;
	}

	@Override
	public boolean checkPolicyNo(long policyNo) throws ClaimException {
		// TODO Auto-generated method stub
		return false;
	}

}
