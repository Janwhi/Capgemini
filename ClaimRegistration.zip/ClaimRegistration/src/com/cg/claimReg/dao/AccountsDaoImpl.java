package com.cg.claimReg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.connection.JDBC;
import com.cg.claimReg.model.Accounts;
import com.cg.claimReg.model.Policy;

public class AccountsDaoImpl implements AccountsDao {
	static Logger logger = Logger.getLogger(AccountsDaoImpl.class);

	@Override
	public List<Policy> getPolicyList(String userName) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		PreparedStatement preparedStatement = null;
		ResultSet set = null;
		long accountNo = 0l;
		List<Policy> policyList = new ArrayList<>();
		connection = JDBC.getConnection();
		logger.info("connection created");
		
		try {
			statement = connection.prepareStatement(QueryMapper.getAccountNoQuery);
			logger.info("connection created");

			statement.setString(1, userName);
			set = statement.executeQuery();
			logger.info("resultset created");
			boolean result = set.next();

			if (result == true) {
				accountNo = set.getLong("ACCOUNT_NO");
				preparedStatement = connection.prepareStatement(QueryMapper.viewPolicy);
				preparedStatement.setLong(1, accountNo);
				set = preparedStatement.executeQuery();

				while (set.next()) {
					long policyNo = set.getLong("POLICY_NO");
					String policyType = set.getString("POLICY_TYPE");
					double premium = set.getDouble("POLICY_PREMIUM");
					long accountNo1= set.getLong("ACCOUNT_NO1");

					Policy policy = new Policy();
					policy.setPolicyNo(policyNo);
					policy.setPolicyPremium(premium);
					policy.setAccountNo(accountNo1);
					policy.setPolicyType(policyType);

					policyList.add(policy);
					logger.info("policy added to the list " + policy);
				}
				connection.commit();
			}
		} 
		catch (SQLException e) {
			throw new ClaimException("Sql Exception occured" + e);
		} 
		finally {
			try {
				statement.close();
			} 
			catch (SQLException e) {
				logger.error(e.getMessage());
				System.err.println("Error while closing statement.");
			}
			try {
				statement.close();
			} 
			catch (SQLException e) {
				logger.error(e.getMessage());
				System.err.println("Error while closing statement.");
			}
			try { 
				connection.close();
			} 
			catch (SQLException e) {
				logger.error(e.getMessage());
				System.err.println("Error while closing connection.");
			}
		}

		return policyList;
	}
	
	@Override
	public List<Accounts> getAllAccounts(String user) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		List<Accounts> accounts = new ArrayList<>();
		connection = JDBC.getConnection();

		logger.info("connection created");
		try {
			statement = connection.prepareStatement(QueryMapper.getAllAccountsQuery);
			logger.info("connection created");
			statement.setString(1, user);
			set = statement.executeQuery();
			logger.info("resultset created");

			while (set.next()) {
				long accountNo = set.getLong("ACCOUNT_NO");
				String insuredName = set.getString("INSURED_NAME");
				String userName = set.getString("USER_NAME");

				Accounts account = new Accounts(accountNo, insuredName,userName);
				accounts.add(account);
				logger.info("account added to the list " + account);
			}
			connection.commit();
		} 
		catch (SQLException e) {

			throw new ClaimException("Sql Exception occured" + e);
		} 
		finally {
			try {
				statement.close();
			} 
			catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}
			try {
				statement.close();
			} 
			catch (SQLException e) {
				logger.error(e.getMessage());
				System.err.println("Error while closing statement.");
			}
			try {
				connection.close();
			}
			catch (SQLException e) {
				logger.error(e.getMessage());
				System.err.println("Error while closing connection.");
			}
		}
		return accounts;
	}

}
