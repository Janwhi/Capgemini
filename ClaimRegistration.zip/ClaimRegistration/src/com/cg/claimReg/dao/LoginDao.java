package com.cg.claimReg.dao;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.UserRole;

public interface LoginDao {

	Boolean validateUser(UserRole user) throws ClaimException;

	String getRoleCode(UserRole user) throws ClaimException;

}
