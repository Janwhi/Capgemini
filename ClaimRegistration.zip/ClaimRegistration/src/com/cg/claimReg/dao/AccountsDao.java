package com.cg.claimReg.dao;

import java.util.List;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.Accounts;
import com.cg.claimReg.model.Policy;


public interface AccountsDao {

	List<Policy> getPolicyList(String userName)throws ClaimException;

	List<Accounts> getAllAccounts(String userName)throws ClaimException;

}
