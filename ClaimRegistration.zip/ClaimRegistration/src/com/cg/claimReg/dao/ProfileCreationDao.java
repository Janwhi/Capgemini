package com.cg.claimReg.dao;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.UserRole;

public interface ProfileCreationDao {

	int profileCreation(UserRole role2)throws ClaimException;

}
