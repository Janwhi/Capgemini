package com.cg.claimReg.dao;

import java.util.List;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.Claim;


public interface ReportGenerationDao {

	List<Claim> getAllclaimReport() throws ClaimException;

}
