package com.cg.claimReg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.connection.JDBC;
import com.cg.claimReg.model.ClaimQuestions;


public class ClaimQuestionsDaoImpl implements ClaimQuestionsDao {
	static Logger logger = Logger.getLogger( ClaimQuestionsDaoImpl.class);
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet set = null;
	
	@Override
	public List<ClaimQuestions> getAllClaimQuestions(long policyNo)
			throws ClaimException {
		List<ClaimQuestions> claims = new ArrayList<>();
		connection = JDBC.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.viewClaimQuestions);
			logger.info("connection established..");
			statement.setLong(1, policyNo);
			set = statement.executeQuery();
			logger.info("resultset created");

			while (set.next()) {

				int id = set.getInt("QUES_ID");
				String type = set.getString("POLICY_TYPE");
				String question = set.getString("QUES_DESC");
				String answer1 = set.getString("QUES_ANS1");
				String answer2 = set.getString("QUES_ANS2");

				ClaimQuestions claim = new ClaimQuestions(id, type, question,
						answer1, answer2);

				claims.add(claim);
				logger.info("claim added to the list "+claim);

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		}

		return claims;
	}
	
	@Override
	public String getClaimQuestions(int questionId) throws ClaimException {
		String question = "";
		connection = JDBC.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.getClaimQuestionsQuery);
			logger.info("connection established..");
			statement.setLong(1, questionId);
			set = statement.executeQuery();
			logger.info("resultset created");
			set.next();
			question = set.getString("QUES_DESC");

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		}

		return question;
	}

}
