package com.cg.claimReg.dao;

import java.util.List;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.model.ClaimQuestions;


public interface ClaimQuestionsDao {

	List<ClaimQuestions> getAllClaimQuestions(long policyNo)throws ClaimException;

	String getClaimQuestions(int questionId)throws ClaimException;

}
