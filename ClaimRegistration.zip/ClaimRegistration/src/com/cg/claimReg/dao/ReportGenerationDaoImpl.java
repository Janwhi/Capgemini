package com.cg.claimReg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.claimReg.connection.ClaimException;
import com.cg.claimReg.connection.JDBC;
import com.cg.claimReg.model.Claim;

public class ReportGenerationDaoImpl implements ReportGenerationDao {
	static Logger logger = Logger.getLogger(ReportGenerationDaoImpl.class);


	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet set = null;


	@Override
	public List<Claim> getAllclaimReport() throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		List<Claim> claim = new ArrayList<>();
		connection = JDBC.getConnection();
		logger.info("connection object created");
		try {
			statement = connection.prepareStatement(QueryMapper.viewClaimReportQuery);
			logger.info("connection established..");
			
			set = statement.executeQuery();
			logger.info("resultset created");
					
			while (set.next()) {
				
				long claimNo=set.getLong("CLAIM_NO");
				String claimReason=set.getString("CLAIM_REASON");
				String claimType=set.getString("CLAIM_TYPE");
				long policyNo=set.getLong("POLICY_NO");
				Claim claim2=new Claim(claimNo, claimReason, claimType, policyNo);
		
				claim.add(claim2);

			}

		
		
		
		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured"+e);
		}

		return claim;
	}

}
