package com.cg.claimReg.connection;

public class ClaimException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public ClaimException(String message) {
		super(message);
	}

	
}
