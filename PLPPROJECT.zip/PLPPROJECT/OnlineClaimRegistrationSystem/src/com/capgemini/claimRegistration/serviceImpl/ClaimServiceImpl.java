package com.capgemini.claimRegistration.serviceImpl;

import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.claimRegistration.dao.AccountsDao;
import com.capgemini.claimRegistration.dao.ClaimDao;
import com.capgemini.claimRegistration.dao.ClaimQuestionsDao;
import com.capgemini.claimRegistration.dao.LoginDao;
import com.capgemini.claimRegistration.dao.PolicyDetailsDao;
import com.capgemini.claimRegistration.dao.ProfileCreationDao;
import com.capgemini.claimRegistration.dao.ReportGenerationDao;
import com.capgemini.claimRegistration.daoImpl.AccountsDaoImpl;
import com.capgemini.claimRegistration.daoImpl.ClaimDaoImpl;
import com.capgemini.claimRegistration.daoImpl.ClaimQuestionsDaoImpl;
import com.capgemini.claimRegistration.daoImpl.LoginDaoImpl;
import com.capgemini.claimRegistration.daoImpl.PolicyDetailsDaoImpl;
import com.capgemini.claimRegistration.daoImpl.ProfileCreationDaoImpl;
import com.capgemini.claimRegistration.daoImpl.ReportGenerationDaoImpl;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Accounts;
import com.capgemini.claimRegistration.model.Claim;
import com.capgemini.claimRegistration.model.ClaimQuestions;
import com.capgemini.claimRegistration.service.ClaimService;

public class ClaimServiceImpl implements ClaimService {
	LoginDao dao = new LoginDaoImpl();
	ClaimDao claimDao = new ClaimDaoImpl();
	ClaimQuestionsDao claimQuestion = new ClaimQuestionsDaoImpl();
	ProfileCreationDao creation = new ProfileCreationDaoImpl();
	PolicyDetailsDao policyDetails = new PolicyDetailsDaoImpl();
	ReportGenerationDao report=new  ReportGenerationDaoImpl();
	AccountsDao account = new AccountsDaoImpl();




	@Override
	public boolean isValidClaimReason(String claimReason)
			throws ClaimException {
		String regEx = "[A-Z]{1}[a-zA-Z ]{2,29}";
		return Pattern.matches(regEx, claimReason);
	}

	@Override
	public boolean isValidAccidentCity(String accidentCity)
			throws ClaimException {
		String regEx = "[A-Z]{1}[a-zA-Z ]{2,14}";
		return Pattern.matches(regEx, accidentCity);
	}

	@Override
	public boolean isValidAccidentLocation(String accidentLocation)
			throws ClaimException {
		String regEx = "[A-Z0-9]{1}[a-zA-Z0-9 ,]{2,39}";
		return Pattern.matches(regEx, accidentLocation);
	}

	@Override
	public boolean isValidAccidentState(String accidentState)
			throws ClaimException {
		String regEx = "[A-Z]{1}[a-zA-Z ]{2,14}";
		return Pattern.matches(regEx, accidentState);
	}

	@Override
	public boolean isValidAccidentZip(long accidentZip) throws ClaimException {
		String regEx = "[1-9]{1}[0-9]{4}";
		return Pattern.matches(regEx, String.valueOf(accidentZip));
	}
 
	@Override
	public boolean isValidClaimType(String claimType) throws ClaimException {
		boolean claimTypeFlag = false;
		if (claimType.equalsIgnoreCase("Accident") || claimType.equalsIgnoreCase("Property damage")
				|| claimType.equalsIgnoreCase("Natural Calamities") || claimType.equalsIgnoreCase("Theft"))
			claimTypeFlag = true;
		return claimTypeFlag;
	}

	

	@Override
	public long insertClaimDetails(Claim claim) throws ClaimException {
		return claimDao.insertClaimDetails(claim);
	}

	@Override
	public List<Claim> getAllClaims() throws ClaimException {
		return claimDao.getAllClaims();
	}

	@Override
	public List<ClaimQuestions> getAllClaimQuestions(long policyNumber)
			throws ClaimException {
		return claimQuestion.getAllClaimQuestions(policyNumber);
	}

	

	@Override
	public List<Claim> getAllclaimReport() throws ClaimException {
		return report.getAllclaimReport();
	}


	@Override
	public List<Claim> showInsuredClaims(String userName) throws ClaimException {
		return claimDao.showInsuredClaims(userName);
	}



	@Override
	public List<Accounts> getAllAccounts(String userName) throws ClaimException {
		return account.getAllAccounts(userName);
	}

	@Override
	public List<Claim> showAgentClaims(Long policyNumber) throws ClaimException {
		return claimDao.showAgentClaims(policyNumber);
	}

	@Override
	public Claim getClaimDetails(long policyNumber) throws ClaimException {
		
		return claimDao.getClaimDetails(policyNumber);
	}

	

	@Override
	public String getClaimQuestions(int questionId)
			throws ClaimException {
		return claimQuestion.getClaimQuestions(questionId);
	}

	@Override
	public List<Claim> showAgentCustomerClaim(long accountNumber)
			throws ClaimException {
		return claimDao.showAgentCustomerClaim(accountNumber);
	}


}
