package com.capgemini.claimRegistration.serviceImpl;

import java.util.regex.Pattern;

import com.capgemini.claimRegistration.dao.LoginDao;
import com.capgemini.claimRegistration.dao.ProfileCreationDao;
import com.capgemini.claimRegistration.daoImpl.LoginDaoImpl;
import com.capgemini.claimRegistration.daoImpl.ProfileCreationDaoImpl;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.UserRole;
import com.capgemini.claimRegistration.service.UserService;

public class UserServiceImpl implements UserService{
	
	LoginDao dao = new LoginDaoImpl();
	ProfileCreationDao creation = new ProfileCreationDaoImpl();
	@Override
	public Boolean validateUser(UserRole user) throws ClaimException {

		return dao.validateUser(user);
	}
	@Override
	public String getRoleCode(UserRole user) throws ClaimException {
		return dao.getRoleCode(user);
	}

	@Override
	public boolean isValidUsername(String username) throws ClaimException {
		String regEx = "[A-Z]{1}[a-zA-Z0-9]{3,19}";
		return Pattern.matches(regEx, username);
	}

	@Override
	public boolean isValidPassword(String profilePassword)
			throws ClaimException {
		String regEx = "[A-Z]{1}[a-zA-z0-9@$%*#_-]{6,11}";
		return Pattern.matches(regEx, profilePassword);
	}

	@Override
	public boolean isValidRoleCode(String roleCode) throws ClaimException {
		boolean roleFlag = false;
		if (roleCode.equals("CLAIM ADJUSTER") || roleCode.equals("CLAIM HANDLER")
				|| roleCode.equals("INSURED"))
			roleFlag = true;
		return roleFlag;

	}

	@Override
	public int profileCreation(UserRole newUser) throws ClaimException {
		return creation.profileCreation(newUser);
	}
}
