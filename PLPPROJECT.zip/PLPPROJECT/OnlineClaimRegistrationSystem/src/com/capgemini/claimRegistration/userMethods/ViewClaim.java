package com.capgemini.claimRegistration.userMethods;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Claim;
import com.capgemini.claimRegistration.service.ClaimService;
import com.capgemini.claimRegistration.serviceImpl.ClaimServiceImpl;

public class ViewClaim {
	ClaimService service = new ClaimServiceImpl();

	public void showClaim() throws ClaimException {
		List<Claim> claims = new ArrayList<>();
		claims = service.getAllClaims();

		if (!claims.isEmpty()) {
			System.out.println();
			System.out.printf("%10s %20s %20s %20s %20s %20s %20s %20s",
					"CLAIM NUMBER", "CLAIM REASON", "ACCIDENT LOCATION STREET",
					"ACCIDENT CITY", "ACCIDENT STATE", " ACCIDENT ZIP",
					"CLAIM TYPE", "POLICY NUMBER");
			for (Claim claim2 : claims) {
				System.out.println();
				System.out.printf("%10s %20s %20s %20s %20s %20s %20s %20s\n",
						claim2.getClaimNumber(), claim2.getClaimReason(),
						claim2.getAccidentLocationStreet(),
						claim2.getAccidentCity(), claim2.getAccidentState(),
						claim2.getAccidentZip(), claim2.getClaimType(),
						claim2.getPolicyNumber());
			}
		} else {
			System.err.println("No Claims Available in Database");
		}

	}

	public void showInsuredClaim(String userName) throws ClaimException {

		List<Claim> claims = new ArrayList<>();
		claims = service.showInsuredClaims(userName);

		if (!claims.isEmpty()) {

			System.out.println();
			System.out.printf("%10s %20s %20s %20s %20s %20s %20s %20s",
					"CLAIM_NUMBER", "CLAIM REASON", "ACCIDENT LOCATION STREET",
					"ACCIDENT CITY", "ACCIDENT STATE", " ACCIDENT ZIP",
					"CLAIM TYPE", "POLICY NUMBER");

			for (Claim claim2 : claims) {
				System.out.println();
				System.out.printf("%10s %20s %20s %20s %20s %20s %20s %20s\n",
						claim2.getClaimNumber(), claim2.getClaimReason(),
						claim2.getAccidentLocationStreet(),
						claim2.getAccidentCity(), claim2.getAccidentState(),
						claim2.getAccidentZip(), claim2.getClaimType(),
						claim2.getPolicyNumber());

			}

		} else {
			System.err.println("No Claims Available in Database");
		}
	}

	public void showCustomerClaim(Long policyNumber) throws ClaimException {
		List<Claim> claims = new ArrayList<>();
		claims = service.showAgentClaims(policyNumber);

		if (!claims.isEmpty()) {
			
			for (Claim claim2 : claims) {
				System.out.println(claim2);

			}
		}
		else{
			System.err.println("No claims for policy number:"+policyNumber);
		}

	}

	public void showAgentCustomerClaim(long accountNumber)
			throws ClaimException {
		List<Claim> claims = new ArrayList<>();
		claims = service.showAgentCustomerClaim(accountNumber);

		if (!claims.isEmpty()) {
			
			System.out.println();
			System.out.printf("%10s %20s %20s %20s %20s %20s %20s %20s",
					"CLAIM_NUMBER", "CLAIM REASON", "ACCIDENT LOCATION STREET",
					"ACCIDENT CITY", "ACCIDENT STATE", " ACCIDENT ZIP",
					"CLAIM TYPE", "POLICY NUMBER");

			for (Claim claim2 : claims) {
				System.out.println();
				System.out.printf("%10s %20s %20s %20s %20s %20s %20s %20s",
						claim2.getClaimNumber(), claim2.getClaimReason(),
						claim2.getAccidentLocationStreet(),
						claim2.getAccidentCity(), claim2.getAccidentState(),
						claim2.getAccidentZip(), claim2.getClaimType(),
						claim2.getPolicyNumber());

			}

		}
		else{
			System.err.println("No claims for the customer with account number:"+accountNumber);
		}

	}

}
