package com.capgemini.claimRegistration.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.UserRole;
import com.capgemini.claimRegistration.service.UserService;
import com.capgemini.claimRegistration.serviceImpl.UserServiceImpl;
import com.capgemini.claimRegistration.userRole.ClaimAdjuster;
import com.capgemini.claimRegistration.userRole.ClaimHandler;
import com.capgemini.claimRegistration.userRole.Insured;

public class Main {
	static Logger logger = Logger.getLogger(Main.class);

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file configured..");

		login();

	}

	public static void login() {

		UserService userService = new UserServiceImpl();

		Scanner scanner = null;
		boolean loginFlag = false;
		String userName = null;
		String password = null;
		do {
			System.out
					.println("*******************Online Claim Registration System***************************");

			scanner = new Scanner(System.in);
			System.out.println("LOGIN:");
			System.out.println();
			do {
				System.out.println("Enter User Name:");

				userName = scanner.nextLine();
				try {
					loginFlag = userService.isValidUsername(userName);
				} catch (ClaimException e) {
					System.err.println(e.getMessage());
				}
				if (!loginFlag)
					System.err
							.println("Username first letter should be capital. Username can contain digits and should be in the range of 4 to 15 characters");

			} while (!loginFlag);

			loginFlag = false;
			do {

				System.out.println("Enter Password:");
				password = scanner.nextLine();
				try {
					loginFlag = userService.isValidPassword(password);
				} catch (ClaimException e) {
					System.err.println(e.getMessage());
				}
				if (!loginFlag)
					System.err
							.println("Password first letter should be capital. Password can contain digits and special characters(@ ,$, %, *, #, _, -) must be in the range of 7 to 12");
			} while (!loginFlag);
			loginFlag = false;
			UserRole user = new UserRole(userName, password);

			try {

				Boolean result = userService.validateUser(user);

				if (result) {
					String role1 = userService.getRoleCode(user);
					user.setRoleCode(role1);

					loginFlag = true;

					System.out.println("Access granted");
					System.out.println("Logged In As " + role1);
					System.out.println();
					System.out.println("Welcome " + userName);
					switch (role1) {
					case "CLAIM ADJUSTER":

						ClaimAdjuster adjuster = new ClaimAdjuster();
						try {
							adjuster.admin(user);
						} catch (ClaimException e) {
							System.err.println(e.getMessage());
						}

						break;
					case "INSURED":
						Insured insured = new Insured();
						try {
							insured.insuredMethods(user);
						} catch (ClaimException e) {
							System.err.println(e.getMessage());
						}

						break;
					case "CLAIM HANDLER":
						ClaimHandler claimHandler = new ClaimHandler();
						try {
							claimHandler.agentMethods(user);
						} catch (ClaimException e) {
							System.err.println(e.getMessage());
						}
						break;

					default:
						break;
					}

				} else {
					loginFlag = false;
					System.err.println("Invalid Credentials, Enter Again");
				}

			} catch (ClaimException e) {
				loginFlag = false;
				System.err.println(e.getMessage());

			}

		} while (!loginFlag);

		scanner.close();

	}
}
