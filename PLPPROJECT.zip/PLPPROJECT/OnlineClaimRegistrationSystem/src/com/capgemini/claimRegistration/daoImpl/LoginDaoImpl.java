package com.capgemini.claimRegistration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




import org.apache.log4j.Logger;

import com.capgemini.claimRegistration.dao.LoginDao;
import com.capgemini.claimRegistration.dao.QueryMapper;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.jdbcUtility.JdbcUtility;
import com.capgemini.claimRegistration.model.UserRole;

public class LoginDaoImpl implements LoginDao {
	static Logger logger = Logger.getLogger(LoginDaoImpl.class);

	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet set = null;


	/**
	 * method name : validateUser argument :UserRole class object return type
	 * : boolean author : Capgemini date : 11-03-2019
	 * 
	 * description : This method will take the UserRole class object as an argument and
	 * returns the validation of user role to the user
	 */

	@Override
	public Boolean validateUser(UserRole user) throws ClaimException {
		logger.info("in LoginDaoImpl  class");
		boolean validate=false;
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection.prepareStatement(QueryMapper.validateUser);
			logger.info("connection established..");
			statement.setString(1, user.getUserName());
			statement.setString(2, user.getPassword());
			set = statement.executeQuery();
			logger.info("resultset created");
			validate=set.next();

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Invalid Credentials");
		} finally {

			try {
				statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());

				throw new ClaimException("unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());

				throw new ClaimException("unable to close connection object");
			}
		}

		return validate;

	}

	/**
	 * method name : getRoleCode argument :UserRole class object return type
	 * : String author : Capgemini date : 11-03-2019
	 * 
	 * description : This method will take the UserRole class object as an argument and
	 * returns the role of user 
	 */

	@Override
	public String getRoleCode(UserRole user) throws ClaimException {
		logger.info("in LoginDaoImpl  class");
		String role=null;
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection.prepareStatement(QueryMapper.selectRoleCode);
			logger.info("connection established..");
			statement.setString(1, user.getUserName());
			statement.setString(2, user.getPassword());
			set = statement.executeQuery();
			logger.info("resultset created");
			set.next();
			role = set.getString("ROLE_CODE");

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Invalid Credentials");
		} finally {

			try {
				statement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());

				throw new ClaimException("unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());

				throw new ClaimException("unable to close connection object");
			}
		}

		return role;

	}


	

}
