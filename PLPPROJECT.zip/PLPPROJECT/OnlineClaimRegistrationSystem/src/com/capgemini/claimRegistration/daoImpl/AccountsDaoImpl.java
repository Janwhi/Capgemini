package com.capgemini.claimRegistration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.claimRegistration.dao.AccountsDao;
import com.capgemini.claimRegistration.dao.QueryMapper;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.jdbcUtility.JdbcUtility;
import com.capgemini.claimRegistration.model.Accounts;
import com.capgemini.claimRegistration.model.Policy;

public class AccountsDaoImpl implements AccountsDao {
	static Logger logger = Logger.getLogger(AccountsDaoImpl.class);

	/**
	 * method name :getPolicyList Claim argument : claim class object return
	 * type List<Policy>: Claim List : Capgemini date : 11-03-2019
	 * 
	 * description : This method will take the model object as an argument and
	 * returns the List of policies to the user
	 */
	@Override
	public List<Policy> getPolicyList(String userName) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		PreparedStatement preparedStatement = null;
		ResultSet set = null;
		long accountNumber = 0l;
		List<Policy> policyList = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.getAccountNumberQuery);
			logger.info("connection established..");

			statement.setString(1, userName);

			set = statement.executeQuery();

			logger.info("resultset created");

			boolean result = set.next();

			

			if (result == true) {
				accountNumber = set.getLong("ACCOUNT_NUMBER");
				preparedStatement = connection
						.prepareStatement(QueryMapper.viewPolicy);
				preparedStatement.setLong(1, accountNumber);
				set = preparedStatement.executeQuery();

				while (set.next()) {
					long policyNumber = set.getLong("POLICY_NUMBER");
					String policyType = set.getString("POLICY_TYPE");
					double premium = set.getDouble("POLICY_PREMIUM");
					long accountNo = set.getLong("ACCOUNT_NUMBER");

					Policy policy = new Policy();
					policy.setPolicyNumber(policyNumber);
					policy.setPolicyPremium(premium);
					policy.setAccountNumber(accountNo);
					policy.setPolicyType(policyType);

					policyList.add(policy);
					logger.info("policy added to the list " + policy);

				}

				connection.commit();
			}

		} catch (SQLException e) {

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try { // closing statement
				statement.close();
				

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try { // closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return policyList;

	}
	
	/**
	 * method name :getAllAccounts Claim argument : String object return
	 * type List<Accounts>: Claim List : Capgemini date : 11-03-2019
	 * 
	 * description : This method will take the username as an argument and
	 * returns the List of accounts to the claim handler
	 */

	@Override
	public List<Accounts> getAllAccounts(String user) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		List<Accounts> accounts = new ArrayList<>();
		connection = JdbcUtility.getConnection();

		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.getAllAccountsQuery);
			logger.info("connection established..");
			statement.setString(1, user);
			set = statement.executeQuery();
			logger.info("resultset created");

			while (set.next()) {
				long accountNumber = set.getLong("ACCOUNT_NUMBER");
				String insuredName = set.getString("INSURED_NAME");
				String userName = set.getString("USER_NAME");

				Accounts account = new Accounts(accountNumber, insuredName,
						userName);
				accounts.add(account);
				logger.info("account added to the list " + account);
			}
			connection.commit();

		} catch (SQLException e) {

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}
		return accounts;
	}

}
