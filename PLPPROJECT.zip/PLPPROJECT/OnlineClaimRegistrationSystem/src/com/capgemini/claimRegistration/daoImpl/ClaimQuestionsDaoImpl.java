package com.capgemini.claimRegistration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.claimRegistration.dao.ClaimQuestionsDao;
import com.capgemini.claimRegistration.dao.QueryMapper;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.jdbcUtility.JdbcUtility;
import com.capgemini.claimRegistration.model.ClaimQuestions;

public class ClaimQuestionsDaoImpl implements ClaimQuestionsDao {
	static Logger logger = Logger.getLogger( ClaimQuestionsDaoImpl.class);
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet set = null;
	/**
	 * method name : getAllClaimQuestions argument :long policyNumber 
	 * return type:List<ClaimQuestions>
	 * author : Capgemini date : 11-03-2019
	 * 
	 * description : This method will take the policyNumber as an argument and
	 * returns the list of claimQuestions class object
	 */
	@Override
	public List<ClaimQuestions> getAllClaimQuestions(long policyNumber)
			throws ClaimException {
		List<ClaimQuestions> claims = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.viewClaimQuestions);
			logger.info("connection established..");
			statement.setLong(1, policyNumber);
			set = statement.executeQuery();
			logger.info("resultset created");

			while (set.next()) {

				int id = set.getInt("QUES_ID");
				String type = set.getString("POLICY_TYPE");
				String question = set.getString("QUES_DESC");
				String answer1 = set.getString("QUES_ANS1");
				String answer2 = set.getString("QUES_ANS2");

				ClaimQuestions claim = new ClaimQuestions(id, type, question,
						answer1, answer2);

				claims.add(claim);
				logger.info("claim added to the list "+claim);

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		}

		return claims;
	}
	/**
	 * method name : getClaimQuestions argument :int questionId return type
	 * : String author : Capgemini date : 11-03-2019
	 * 
	 * description : This method will take questionId as an argument and
	 * returns the claim questions based on question id to the user 
	 */
	@Override
	public String getClaimQuestions(int questionId) throws ClaimException {
		String question = "";
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.getClaimQuestionsQuery);
			logger.info("connection established..");
			statement.setLong(1, questionId);
			set = statement.executeQuery();
			logger.info("resultset created");
			set.next();
			question = set.getString("QUES_DESC");

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		}

		return question;
	}

}
