package com.capgemini.claimRegistration.daoImpl.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.claimRegistration.daoImpl.ClaimDaoImpl;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Claim;
import com.capgemini.claimRegistration.model.Policy;

public class ClaimDaoImplTest {
	
	ClaimDaoImpl claimDao=null;
	
	@Before
	public void setUp() throws Exception {
		claimDao=new ClaimDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		claimDao=null;
	}

	@Test
	public void testViewPoliciesNot() {
		List<Policy> list=new ArrayList<>(); 
		try {
			list =claimDao.viewPolicies(1870011501);
			assertNotNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testViewPolicies() {
		List<Policy> list=new ArrayList<>(); 
		try {
			list =claimDao.viewPolicies(1870011502);
			assertNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetAllClaimsNot() {
		List<Claim> list=new ArrayList<Claim>();
		try {
			list=claimDao.getAllClaims();
			assertNotNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}


	@Test
	public void testGetAllClaims() {
		List<Claim> list=new ArrayList<Claim>();
		try {
			list=claimDao.getAllClaims();
			assertNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void testShowInsuredClaimsNot() {
		List<Claim> list=new ArrayList<Claim>();
		try {
			list=claimDao.showInsuredClaims("Ahana");
			assertNotNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testShowInsuredClaims() {
		List<Claim> list=new ArrayList<Claim>();
		try {
			list=claimDao.showInsuredClaims("Aman");
			assertNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

	
	@Test
	public void testCheckPolicyNumber() {
		try {
			boolean isPolicyNumber=claimDao.checkPolicyNumber(10005);
			assertTrue(isPolicyNumber);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testCheckPolicyNumberFalse() {
		try {
			boolean isPolicyNumber=claimDao.checkPolicyNumber(10111);
			assertTrue(isPolicyNumber);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetPolicyListNot() {
		List<Policy> list=new ArrayList<Policy>();
		try {
			list=claimDao.getPolicyList();
			assertNotNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testGetPolicyList() {
		List<Policy> list=new ArrayList<Policy>();
		try {
			list=claimDao.getPolicyList();
			assertNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testShowAgentClaimsNot() {
		List<Claim> list=new ArrayList<>();
		try {
			list=claimDao.showAgentClaims(10002l);
			assertNotNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testShowAgentClaims() {
		List<Claim> list=new ArrayList<>();
		try {
			list=claimDao.showAgentClaims(10002l);
			assertNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetClaimDetailsNot() {
		try {
			Claim claim=claimDao.getClaimDetails(10002l);
			assertNotNull(claim);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testGetClaimDetails() {
		try {
			Claim claim=claimDao.getClaimDetails(10002l);
			assertNull(claim);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testShowAgentCustomerClaimNot() {
		List<Claim> list=new ArrayList<>();
		try {
			list=claimDao.showAgentCustomerClaim(1870011501);
			assertNotNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testShowAgentCustomerClaim() {
		List<Claim> list=new ArrayList<>();
		try {
			list=claimDao.showAgentCustomerClaim(1870011501);
			assertNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	
}
