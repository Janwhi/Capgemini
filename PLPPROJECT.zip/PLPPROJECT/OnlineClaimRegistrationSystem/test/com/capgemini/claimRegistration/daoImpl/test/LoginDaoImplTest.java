package com.capgemini.claimRegistration.daoImpl.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.claimRegistration.daoImpl.LoginDaoImpl;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.UserRole;

public class LoginDaoImplTest {
	LoginDaoImpl loginDao = null;

	@Before
	public void setUp() throws Exception {
		loginDao = new LoginDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		loginDao = null;
	}

	@Test
	public void testValidateUser() {
		 UserRole user = new UserRole();
		 user.setUserName("Kabir");
		 user.setPassword("Kabir123");
		 user.setRoleCode("CLAIM HANDLER");
		 try {
			Boolean validUser = loginDao.validateUser(user);
			assertTrue(validUser);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testValidateUserFalse() {
		 UserRole user = new UserRole();
		 user.setUserName("Kabir");
		 user.setPassword("Kabir12");
		 user.setRoleCode("CLAIM HANDLER");
		 try {
			Boolean validUser = loginDao.validateUser(user);
			assertTrue(validUser);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testGetRoleCodeNot() {
		 UserRole user = new UserRole();
		 user.setUserName("Kabir");
		 user.setPassword("Kabir123");
		try {
			String roleCode = loginDao.getRoleCode(user);
			assertNotNull(roleCode);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetRoleCode() {
		 UserRole user = new UserRole();
		 user.setUserName("Kabir");
		 user.setPassword("Kabir123");
		try {
			String roleCode = loginDao.getRoleCode(user);
			assertNull(roleCode);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

}
